# app.py
from flask import Flask, request, jsonify
from flask_cors import CORS
from werkzeug.utils import secure_filename
import os
import json
from datetime import datetime
import sqlite3
from pathlib import Path
import PyPDF2
import fitz

from ai_5 import run_document_agent

app = Flask(__name__)
CORS(app)

# Configuration
UPLOAD_FOLDER = 'uploads/pdfs'
DATABASE = 'simulation.db'
ALLOWED_EXTENSIONS = {'pdf'}
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_FILE_SIZE

# Ensure upload directory exists
Path(UPLOAD_FOLDER).mkdir(parents=True, exist_ok=True)


# Database initialization
def init_db():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    # Create uploads table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS uploaded_files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id TEXT,
            filename TEXT NOT NULL,
            original_filename TEXT NOT NULL,
            file_path TEXT NOT NULL,
            file_size INTEGER,
            extracted_text TEXT,
            page_count INTEGER,
            upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'active'
        )
    ''')

    conn.commit()
    conn.close()


init_db()


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def extract_text_pypdf2(file_path):
    try:
        text = ""
        with open(file_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            page_count = len(pdf_reader.pages)

            for page_num in range(page_count):
                page = pdf_reader.pages[page_num]
                text += page.extract_text() + "\n\n"

        return text.strip(), page_count
    except Exception as e:
        print(f"PyPDF2 extraction error: {e}")
        return None, 0


def extract_text_pymupdf(file_path):
    try:
        doc = fitz.open(file_path)
        text = ""
        page_count = len(doc)

        for page_num in range(page_count):
            page = doc[page_num]
            text += page.get_text() + "\n\n"

        doc.close()
        return text.strip(), page_count
    except Exception as e:
        print(f"PyMuPDF extraction error: {e}")
        return None, 0

def chat():
    try:
        data = request.get_json()
        user_message = data.get('message', '')
        response = (run_document_agent(user_message)[1]).content
        print('''
        
        
        response= ''',response)

        # TODO: Integrate your chatbot/LLM logic here
        response_message = f"You said: {user_message}\n\nThis is a placeholder response. Integrate your AI model here."
        generate_diagram({'equipment_list': {'Feed-1': 'Feed', 'Tank-1': 'Tank', 'Product-1': 'Product'}, 'connection': [{'equipment': 'Feed-1', 'outlet': ['Tank-1763757377914'], 'Param': {}}, {'equipment': 'Tank-1', 'outlet': ['Product-1763757379250'], 'Param': {'Temperature': 300, 'Pressure': 1}}, {'equipment': 'Product-1', 'outlet': [], 'Param': {}}]} )
        return jsonify({
            'message': response,
            'timestamp': datetime.now().isoformat()
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# Chat endpoint
@app.route('/api/chat', methods=['POST'])
def chat():
    try:
        data = request.get_json()
        user_message = data.get('message', '')
        project_id = data.get('project_id', '')

        # Get PDF context if available
        pdf_context = ""
        if project_id:
            conn = sqlite3.connect(DATABASE)
            cursor = conn.cursor()
            cursor.execute('''
                SELECT extracted_text FROM uploaded_files 
                WHERE project_id = ? AND status = 'active' 
                ORDER BY upload_date DESC LIMIT 1
            ''', (project_id,))
            result = cursor.fetchone()
            conn.close()

            if result and result[0]:
                pdf_context = f"\n\nPDF Context:\n{result[0][:5000]}"  # Limit to first 5000 chars

        # TODO: Integrate your chatbot/LLM with PDF context
        response_message = f"You said: {user_message}\n\nPDF Context Available: {'Yes' if pdf_context else 'No'}\n\nThis is a placeholder. Integrate your AI model here."

        return jsonify({
            'message': response_message,
            'has_pdf_context': bool(pdf_context),
            'timestamp': datetime.now().isoformat()
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# Generate flow diagram endpoint
@app.route('/api/generate-diagram', methods=['POST'])
def generate_diagram(json_info):
    try:
        data = request.get_json()
        data=json_info
        nodes = data.get('nodes', [])
        edges = data.get('edges', [])

        # TODO: Implement diagram generation logic

        return jsonify({
            'diagram': 'base64_encoded_image_or_svg_string',
            'nodes': nodes,
            'edges': edges,
            'message': 'Diagram generated successfully'
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# Run simulation endpoint
@app.route('/api/run-simulation', methods=['POST'])
def run_simulation():
    try:
        data = request.get_json()
        print('data',data)
        equipment_list = data.get('equipment_list', {})
        connection = data.get('connection', [])

        # TODO: Implement your simulation logic here

        results = [
            {'parameter': 'Temperature', 'value': '350 K', 'status': 'Nominal'},
            {'parameter': 'Pressure', 'value': '1.5 bar', 'status': 'Normal'},
            {'parameter': 'Flow Rate', 'value': '100 kg/h', 'status': 'Optimal'},
        ]

        return jsonify({
            'status': 'success',
            'results': results,
            'message': 'Simulation completed successfully'
        }), 200
    except Exception as e:
        return jsonify({'error': str(e), 'status': 'failed'}), 500


# NEW: Upload PDF endpoint
@app.route('/api/upload-pdf', methods=['POST'])
def upload_pdf():
    try:
        # Check if file is present
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400

        file = request.files['file']

        # Check if file is selected
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400

        # Validate file type
        if not allowed_file(file.filename):
            return jsonify({'error': 'Only PDF files are allowed'}), 400

        # Get project ID if provided
        project_id = request.form.get('project_id', 'default')

        # Secure the filename
        original_filename = secure_filename(file.filename)

        # Create unique filename with timestamp
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"{timestamp}_{original_filename}"

        # Full file path
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)

        # Save file
        file.save(file_path)

        # Get file size
        file_size = os.path.getsize(file_path)

        # Save to database
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()

        cursor.execute('''
            INSERT INTO uploaded_files 
            (project_id, filename, original_filename, file_path, file_size)
            VALUES (?, ?, ?, ?, ?)
        ''', (project_id, filename, original_filename, file_path, file_size))

        file_id = cursor.lastrowid
        conn.commit()
        conn.close()

        return jsonify({
            'status': 'success',
            'message': 'PDF uploaded successfully',
            'filename': filename,
            'original_filename': original_filename,
            'file_path': file_path,
            'file_size': file_size,
            'file_id': file_id
        }), 200

    except Exception as e:
        return jsonify({'error': str(e), 'status': 'failed'}), 500


# NEW: Get uploaded files for a project
@app.route('/api/files/<project_id>', methods=['GET'])
def get_project_files(project_id):
    try:
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()

        cursor.execute('''
            SELECT id, filename, original_filename, file_path, file_size, upload_date
            FROM uploaded_files
            WHERE project_id = ? AND status = 'active'
            ORDER BY upload_date DESC
        ''', (project_id,))

        files = []
        for row in cursor.fetchall():
            files.append({
                'id': row[0],
                'filename': row[1],
                'original_filename': row[2],
                'file_path': row[3],
                'file_size': row[4],
                'upload_date': row[5]
            })

        conn.close()

        return jsonify({
            'status': 'success',
            'files': files
        }), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 500


# NEW: Delete uploaded file
@app.route('/api/delete-file/<int:file_id>', methods=['DELETE'])
def delete_file(file_id):
    try:
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()

        # Get file info
        cursor.execute('SELECT file_path FROM uploaded_files WHERE id = ?', (file_id,))
        result = cursor.fetchone()

        if not result:
            return jsonify({'error': 'File not found'}), 404

        file_path = result[0]

        # Delete physical file
        if os.path.exists(file_path):
            os.remove(file_path)

        # Mark as deleted in database
        cursor.execute('UPDATE uploaded_files SET status = ? WHERE id = ?', ('deleted', file_id))
        conn.commit()
        conn.close()

        return jsonify({
            'status': 'success',
            'message': 'File deleted successfully'
        }), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
