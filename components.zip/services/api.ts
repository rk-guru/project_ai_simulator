// src/services/api.ts
import axios, { AxiosResponse } from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

export interface ChatResponse {
  message: string;
  timestamp?: string;
}

export interface FlowDiagramResponse {
  diagram: string;
  nodes: any[];
  edges: any[];
}

export interface SimulationResponse {
  status: string;
  results: any[];
  message: string;
}

// NEW: PDF Upload Response Interface
export interface PDFUploadResponse {
  status: string;
  message: string;
  filename: string;
  file_path: string;
  file_id?: number;
}

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 30000,
});

export const sendChatMessage = async (message: string): Promise<ChatResponse> => {
  try {
    const response: AxiosResponse<ChatResponse> = await apiClient.post('/chat', {
      message: message,
      timestamp: new Date().toISOString(),
    });
    return response.data;
  } catch (error: any) {
    console.error('Chat API Error:', error);
    throw new Error(error.response?.data?.message || 'Failed to send chat message');
  }
};

export const generateFlowDiagram = async (nodes: any[], edges: any[]): Promise<FlowDiagramResponse> => {
  try {
    const response: AxiosResponse<FlowDiagramResponse> = await apiClient.post('/generate-diagram', {
      nodes: nodes,
      edges: edges,
    });
    return response.data;
  } catch (error: any) {
    console.error('Flow Diagram API Error:', error);
    throw new Error(error.response?.data?.message || 'Failed to generate flow diagram');
  }
};

export const runSimulation = async (simulationData: any): Promise<SimulationResponse> => {
  try {
    const response: AxiosResponse<SimulationResponse> = await apiClient.post('/run-simulation', {
      equipment_list: simulationData.Equipment_list,
      connection: simulationData.Connection,
    });
    return response.data;
  } catch (error: any) {
    console.error('Simulation API Error:', error);
    throw new Error(error.response?.data?.message || 'Failed to run simulation');
  }
};

// NEW: Upload PDF Function
export const uploadPDF = async (file: File, projectId?: string): Promise<PDFUploadResponse> => {
  try {
    const formData = new FormData();
    formData.append('file', file);
    if (projectId) {
      formData.append('project_id', projectId);
    }

    const response: AxiosResponse<PDFUploadResponse> = await axios.post(
      `${API_BASE_URL}/upload-pdf`,
      formData,
      {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        timeout: 60000, // 60 seconds for large files
      }
    );
    return response.data;
  } catch (error: any) {
    console.error('PDF Upload API Error:', error);
    throw new Error(error.response?.data?.message || 'Failed to upload PDF');
  }
};

export default apiClient;
