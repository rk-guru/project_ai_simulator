
import React, { useState } from 'react';
import { Project } from '../types';
import Chatbot from './Chatbot';
import FlowDiagram from './FlowDiagram';
import ResultTable from './ResultTable';
import SaveIcon from './icons/SaveIcon';
import PlayIcon from './icons/PlayIcon';

interface MainContentProps {
  project: Project;
}

type Tab = 'simulation' | 'flow-diagram' | 'result-table';

const MainContent: React.FC<MainContentProps> = ({ project }) => {
  const [projectName, setProjectName] = useState(project.name);
  const [activeTab, setActiveTab] = useState<Tab>('simulation');

  const renderTabContent = () => {
    switch (activeTab) {
      case 'simulation':
        return <Chatbot />;
      case 'flow-diagram':
        return <FlowDiagram />;
      case 'result-table':
        return <ResultTable />;
      default:
        return null;
    }
  };

  const TabButton = ({ tab, label }: { tab: Tab; label: string }) => (
    <button
      onClick={() => setActiveTab(tab)}
      className={`px-4 py-2 text-sm font-medium rounded-t-md transition-colors ${
        activeTab === tab
          ? 'bg-slate-800 text-white border-b-2 border-indigo-500'
          : 'text-gray-400 hover:bg-slate-700/50'
      }`}
    >
      {label}
    </button>
  );

  return (
    <div className="flex-1 flex flex-col bg-slate-900">
      {/* Header */}
      <div className="flex-shrink-0 p-6 border-b border-slate-700/50">
        <div className="flex justify-between items-center">
          <div className="flex flex-col">
            <label htmlFor="projectName" className="text-xs text-gray-400 mb-1">Project Name</label>
            <input
              id="projectName"
              type="text"
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
              className="text-lg font-semibold bg-transparent border-none text-white focus:ring-0 -ml-1"
            />
          </div>
        </div>
      </div>
      
      {/* Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Tabs */}
        <div className="flex-shrink-0 px-6 border-b border-slate-700/50">
          <nav className="flex space-x-2">
            <TabButton tab="simulation" label="Simulation" />
            <TabButton tab="flow-diagram" label="Flow Diagram" />
            <TabButton tab="result-table" label="Result Table" />
          </nav>
        </div>
        
        {/* Tab Panel */}
        <div className="flex-1 overflow-y-auto p-6">
          {renderTabContent()}
        </div>
      </div>

      {/* Footer */}
      <div className="flex-shrink-0 p-4 bg-slate-800/30 border-t border-slate-700/50 flex justify-end items-center space-x-4">
        <button className="flex items-center px-4 py-2 text-sm font-semibold text-white bg-slate-600 rounded-md hover:bg-slate-500 transition-colors">
          <SaveIcon className="w-5 h-5 mr-2" />
          Save
        </button>
        <button className="flex items-center px-4 py-2 text-sm font-semibold text-white bg-green-600 rounded-md hover:bg-green-500 transition-colors">
          <PlayIcon className="w-5 h-5 mr-2" />
          Run
        </button>
      </div>
    </div>
  );
};

export default MainContent;
