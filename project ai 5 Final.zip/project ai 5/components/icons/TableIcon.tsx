
import React from 'react';

const TableIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.375 19.5h17.25m-17.25 0a1.125 1.125 0 01-1.125-1.125M3.375 19.5a1.125 1.125 0 001.125 1.125m17.25 0a1.125 1.125 0 001.125-1.125m-1.125 1.125a1.125 1.125 0 01-1.125-1.125M3.75 6.75h16.5M3.75 12h16.5M12 17.25V4.125" />
  </svg>
);

export default TableIcon;
