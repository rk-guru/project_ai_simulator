
import React from 'react';

const MessageIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M7.5 8.25h9m-9 3h9m-9 3h3m-4.5 5.25L3 21V4.5A2.25 2.25 0 015.25 2.25h13.5A2.25 2.25 0 0121 4.5V15a2.25 2.25 0 01-2.25 2.25H6.75L4.5 19.5z" />
  </svg>
);

export default MessageIcon;
