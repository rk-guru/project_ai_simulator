
import React, { useState, useEffect, useRef } from 'react';
import { FlowsheetNode, FlowsheetEdge, EquipmentType } from '../types';
import CloseIcon from './icons/CloseIcon';
import TrashIcon from './icons/TrashIcon';
import { dbService } from '../services/db';

interface PropertiesPanelProps {
  node: FlowsheetNode;
  allNodes: FlowsheetNode[];
  edges: FlowsheetEdge[];
  onNodeUpdate: (updatedNode: FlowsheetNode) => void;
  onAddEdge: (fromId: string, toId: string) => void;
  onRemoveEdge: (edgeId: string) => void;
  onClose: () => void;
}

const CONNECTION_RULES: Record<EquipmentType, { maxInputs: number; maxOutputs: number }> = {
    [EquipmentType.Feed]: { maxInputs: 0, maxOutputs: 1 },
    [EquipmentType.Product]: { maxInputs: 1, maxOutputs: 0 },
    [EquipmentType.Heater]: { maxInputs: 1, maxOutputs: 1 },
    [EquipmentType.Cooler]: { maxInputs: 1, maxOutputs: 1 },
    [EquipmentType.Pump]: { maxInputs: 1, maxOutputs: 1 },
    [EquipmentType.Compressor]: { maxInputs: 1, maxOutputs: 1 },
    [EquipmentType.Expander]: { maxInputs: 1, maxOutputs: 1 },
    [EquipmentType.HeatExchanger]: { maxInputs: 1, maxOutputs: 1 },
    [EquipmentType.Reactor]: { maxInputs: 1, maxOutputs: 2 },
    [EquipmentType.Flash]: { maxInputs: 1, maxOutputs: 2 },
    [EquipmentType.Tank]: { maxInputs: 1, maxOutputs: 2 },
    [EquipmentType.DistillationColumn]: { maxInputs: 1, maxOutputs: 2 },
    [EquipmentType.Mixer]: { maxInputs: Infinity, maxOutputs: 1 },
    [EquipmentType.Splitter]: { maxInputs: 1, maxOutputs: Infinity },
};

const PropertyInput: React.FC<{label: string, name: string, value: any, unit?: string, onChange: (e: React.ChangeEvent<HTMLInputElement>) => void}> = ({ label, name, value, unit, onChange }) => (
    <div>
        <label htmlFor={name} className="text-xs text-gray-400 block mb-1">{label}</label>
        <div className="flex items-center">
            <input 
                id={name}
                name={name}
                type="number"
                value={value}
                onChange={onChange}
                className="w-full bg-slate-700 border border-slate-600 rounded-md px-3 py-1.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            {unit && <span className="text-sm text-gray-400 ml-2 flex-shrink-0">{unit}</span>}
        </div>
    </div>
);


const PropertiesPanel: React.FC<PropertiesPanelProps> = ({
  node,
  allNodes,
  edges,
  onNodeUpdate,
  onAddEdge,
  onRemoveEdge,
  onClose,
}) => {
  const [chemicals, setChemicals] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);
  const [selectedInputToAdd, setSelectedInputToAdd] = useState('');
  const [selectedOutputToAdd, setSelectedOutputToAdd] = useState('');

  // Fetch chemicals on mount
  useEffect(() => {
    const fetchChemicals = async () => {
        const list = await dbService.getChemicals();
        setChemicals(list);
    };
    fetchChemicals();
  }, []);

  const otherNodes = allNodes.filter(n => n.id !== node.id);

  const inputs = edges.filter(e => e.to === node.id);
  const outputs = edges.filter(e => e.from === node.id);
// --- Splitter: split ratio per outlet (sum must be 1) ---
  const clamp01 = (x: number) => Math.max(0, Math.min(1, x));

  const isSplitter = node.type === EquipmentType.Splitter;

// Split ratios stored on the splitter node, keyed by outlet node id (edge.to)
  const splitRatios: Record<string, number> = node.properties.splitRatios || {};

// Current outlet ids (destination node ids)
  const outputIds = outputs.map(e => e.to);

  const setSplitRatios = (next: Record<string, number>) => {
  onNodeUpdate({
    ...node,
    properties: {
    ...node.properties,
    splitRatios: next,
    },
  });
  };

  
  const rules = CONNECTION_RULES[node.type];
  const canAddInput = inputs.length < rules.maxInputs;
  const canAddOutput = outputs.length < rules.maxOutputs;

  const availableInputNodes = otherNodes.filter(n => {
    if (inputs.some(i => i.from === n.id)) return false; 
    const nodeOutputsCount = edges.filter(e => e.from === n.id).length;
    const nodeRules = CONNECTION_RULES[n.type];
    return nodeOutputsCount < nodeRules.maxOutputs;
  });

  const availableOutputNodes = otherNodes.filter(n => {
    if (outputs.some(o => o.to === n.id)) return false; 
    const nodeInputsCount = edges.filter(e => e.to === n.id).length;
    const nodeRules = CONNECTION_RULES[n.type];
    return nodeInputsCount < nodeRules.maxInputs;
  });

  const getNodeName = (id: string) => allNodes.find(n => n.id === id)?.name || 'Unknown';

//   const handleAddOutput = (e: React.ChangeEvent<HTMLSelectElement>) => {
//     const toId = e.target.value;
//     if (toId) {
//         onAddEdge(node.id, toId);
//         setSelectedOutputToAdd(''); // Reset controlled input
//     }
//   };
  const handleAddOutput = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const toId = e.target.value;
    if (!toId) return;

    onAddEdge(node.id, toId);
    setSelectedOutputToAdd(''); // Reset controlled input

    // If splitter, initialize/rebalance ratios so total stays = 1
    if (isSplitter) {
        const newOutputIds = [...outputIds, toId];
        const eq = newOutputIds.length > 0 ? 1 / newOutputIds.length : 0;

        const next: Record<string, number> = {};
        newOutputIds.forEach(id => (next[id] = eq));
        setSplitRatios(next);
    }
    };


  
  const handleAddInput = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const fromId = e.target.value;
    if (fromId) {
        onAddEdge(fromId, node.id);
        setSelectedInputToAdd(''); // Reset controlled input
    }
  };
  
  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onNodeUpdate({ ...node, name: e.target.value });
  };

  const handlePropertyChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    const isNumber = e.target.type === 'number';
    
    onNodeUpdate({
      ...node,
      properties: {
        ...node.properties,
        [name]: isNumber ? parseFloat(value) || 0 : value,
      }
    });
  };
  const handleRemoveOutputEdge = (edgeId: string, toId: string) => {
  onRemoveEdge(edgeId);

  if (!isSplitter) return;

  const remaining = outputIds.filter(id => id !== toId);

  if (remaining.length === 0) {
    setSplitRatios({});
    return;
  }

  // Re-equalize after removal (simple + stable)
  const eq = 1 / remaining.length;
  const next: Record<string, number> = {};
  remaining.forEach(id => (next[id] = eq));
  setSplitRatios(next);
};

  const handleSplitRatioChange = (toId: string, newValueStr: string) => {
  if (!isSplitter) return;

  const newVal = clamp01(parseFloat(newValueStr) || 0);
  const others = outputIds.filter(id => id !== toId);

  // If only one outlet, it must be 1
  if (others.length === 0) {
    setSplitRatios({ [toId]: 1 });
    return;
  }

  const remainder = 1 - newVal;

  // Preserve existing proportions among the other outlets
  const oldOthersSum = others.reduce((acc, id) => acc + (splitRatios[id] ?? 0), 0);

  const next: Record<string, number> = { ...splitRatios, [toId]: newVal };

  if (oldOthersSum > 0) {
    others.forEach(id => {
      next[id] = ((splitRatios[id] ?? 0) / oldOthersSum) * remainder;
    });
  } else {
    const eq = remainder / others.length;
    others.forEach(id => (next[id] = eq));
  }

  setSplitRatios(next);
};


  // --- Compound Management Logic ---
  const handleAddCompound = (chemicalName: string) => {
      const currentCompounds = node.properties.compounds || [];
      if (!currentCompounds.some((c: any) => c.name === chemicalName)) {
          onNodeUpdate({
              ...node,
              properties: {
                  ...node.properties,
                  compounds: [...currentCompounds, { name: chemicalName, moleFraction: 0 }]
              }
          });
      }
      setSearchTerm('');
      setShowDropdown(false);
  };

  const handleRemoveCompound = (chemicalName: string) => {
      const currentCompounds = node.properties.compounds || [];
      onNodeUpdate({
          ...node,
          properties: {
              ...node.properties,
              compounds: currentCompounds.filter((c: any) => c.name !== chemicalName)
          }
      });
  };

  const handleMoleFractionChange = (chemicalName: string, newValue: string) => {
      const currentCompounds = node.properties.compounds || [];
      const updatedCompounds = currentCompounds.map((c: any) => {
          if (c.name === chemicalName) {
              return { ...c, moleFraction: parseFloat(newValue) || 0 };
          }
          return c;
      });
      onNodeUpdate({
          ...node,
          properties: {
              ...node.properties,
              compounds: updatedCompounds
          }
      });
  };
  
  // Filtered chemicals based on search
  const filteredChemicals = chemicals.filter(c => 
      c.toLowerCase().includes(searchTerm.toLowerCase())
  );


  const renderCompositionSection = () => {
    const compounds = node.properties.compounds || [];
    const totalFraction = compounds.reduce((acc: number, curr: any) => acc + (curr.moleFraction || 0), 0);
    const isTotalValid = Math.abs(totalFraction - 1.0) < 0.01;

    return (
        <div className="mt-4 border-t border-slate-700/50 pt-4">
            <h4 className="text-sm font-semibold text-gray-300 mb-2">Composition</h4>
            
            {/* List of added compounds */}
            <div className="space-y-2 mb-3">
                {compounds.length === 0 && <p className="text-xs text-gray-500 italic">No compounds added</p>}
                {compounds.map((comp: any) => (
                    <div key={comp.name} className="flex items-center space-x-2 bg-slate-700/30 p-2 rounded">
                        <span className="text-xs text-gray-200 flex-1 truncate" title={comp.name}>{comp.name}</span>
                        <input 
                            type="number" 
                            step="0.01"
                            min="0"
                            max="1"
                            value={comp.moleFraction}
                            onChange={(e) => handleMoleFractionChange(comp.name, e.target.value)}
                            className="w-16 bg-slate-800 border border-slate-600 rounded px-1 text-xs text-right text-white focus:ring-1 focus:ring-indigo-500"
                        />
                        <button 
                            onClick={() => handleRemoveCompound(comp.name)}
                            className="text-gray-500 hover:text-red-400"
                        >
                            <TrashIcon className="w-3 h-3" />
                        </button>
                    </div>
                ))}
            </div>

            {/* Total Indicator */}
            {compounds.length > 0 && (
                <div className="flex justify-between text-xs mb-3 px-2">
                    <span className="text-gray-400">Total Fraction:</span>
                    <span className={isTotalValid ? "text-green-400 font-bold" : "text-red-400 font-bold"}>
                        {totalFraction.toFixed(3)}
                    </span>
                </div>
            )}

            {/* Add Compound Dropdown */}
            <div className="relative">
                <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    onFocus={() => setShowDropdown(true)}
                    onBlur={() => setTimeout(() => setShowDropdown(false), 200)} // Delay to allow click
                    placeholder="Add Compound..."
                    className="w-full bg-slate-700 border border-slate-600 rounded-md px-3 py-1.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-gray-500"
                />
                {showDropdown && filteredChemicals.length > 0 && (
                    <ul className="absolute z-10 bottom-full mb-1 w-full bg-slate-800 border border-slate-600 rounded-md shadow-lg max-h-40 overflow-y-auto">
                        {filteredChemicals.map(chem => (
                            <li 
                                key={chem}
                                onClick={() => handleAddCompound(chem)}
                                className="px-3 py-2 text-sm text-gray-300 hover:bg-indigo-600 hover:text-white cursor-pointer"
                            >
                                {chem}
                            </li>
                        ))}
                    </ul>
                )}
            </div>
        </div>
    );
  };


  const renderParameters = () => {
    const { type, properties } = node;
    const params: React.ReactElement[] = [];

    switch(type) {
        case EquipmentType.Feed:
            params.push(<PropertyInput key="temp" label="Temperature" name="temperature" unit="K" value={properties.temperature} onChange={handlePropertyChange} />);
            params.push(<PropertyInput key="press" label="Pressure" name="pressure" unit="bar" value={properties.pressure} onChange={handlePropertyChange} />);
            params.push(<PropertyInput key="flow" label="Flow Rate" name="flowRate" unit="kmol/hr" value={properties.flowRate} onChange={handlePropertyChange} />);
            break;
        case EquipmentType.Tank:
        case EquipmentType.Flash:
        case EquipmentType.Reactor:
            params.push(<PropertyInput key="temp" label="Temperature" name="temperature" unit="K" value={properties.temperature} onChange={handlePropertyChange} />);
            params.push(<PropertyInput key="press" label="Pressure" name="pressure" unit="bar" value={properties.pressure} onChange={handlePropertyChange} />);
            break;
        case EquipmentType.Pump:
        case EquipmentType.Compressor:
        case EquipmentType.Expander:
            params.push(<PropertyInput key="out-press" label="Output Pressure" name="outletPressure" unit="bar" value={properties.outletPressure} onChange={handlePropertyChange} />);
            break;
        case EquipmentType.Heater:
        case EquipmentType.Cooler:
            params.push(<PropertyInput key="out-temp" label="Outlet Temperature" name="outletTemperature" unit="K" value={properties.outletTemperature} onChange={handlePropertyChange} />);
            break;
        case EquipmentType.DistillationColumn:
            params.push(<PropertyInput key="stages" label="Number of Stages" name="stages" value={properties.stages} onChange={handlePropertyChange} />);
            params.push(
                <div key="condenser">
                    <label htmlFor="condenserType" className="text-xs text-gray-400 block mb-1">Condenser Type</label>
                    <select id="condenserType" name="condenserType" value={properties.condenserType} onChange={handlePropertyChange} className="w-full bg-slate-700 border border-slate-600 rounded-md px-3 py-1.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        <option>Total</option>
                        <option>Partial</option>
                    </select>
                </div>
            );
            params.push(<PropertyInput key="dist-press" label="Pressure" name="pressure" unit="bar" value={properties.pressure} onChange={handlePropertyChange} />);
            params.push(<PropertyInput key="dist-temp" label="Temperature" name="temperature" unit="K" value={properties.temperature} onChange={handlePropertyChange} />);
            params.push(<PropertyInput key="reflux" label="Reflux Ratio" name="refluxRatio" value={properties.refluxRatio} onChange={handlePropertyChange} />);
            break;
    }
    
    // Always render parameters if available, or if it's a Feed, render composition too
    
    return (
        <div>
            {params.length > 0 && (
                 <div className="mb-4">
                    <h4 className="text-sm font-semibold text-gray-300 mb-2">Parameters</h4>
                    <div className="space-y-3">{params}</div>
                </div>
            )}
            
            {type === EquipmentType.Feed && renderCompositionSection()}
        </div>
    );
  };


  return (
    <div className="w-72 bg-slate-800/50 rounded-lg p-4 flex flex-col space-y-4 flex-shrink-0">
        <div className="flex justify-between items-center">
            <h3 className="text-md font-bold text-gray-200">Properties</h3>
            <button onClick={onClose} className="text-gray-400 hover:text-white">
                <CloseIcon className="w-5 h-5" />
            </button>
        </div>
        
        {/* Name Editor */}
        <div>
            <label htmlFor="nodeName" className="text-xs text-gray-400 block mb-1">Equipment Name</label>
            <input 
                id="nodeName"
                type="text"
                value={node.name}
                onChange={handleNameChange}
                className="w-full bg-slate-700 border border-slate-600 rounded-md px-3 py-1.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
        </div>

        {/* Parameters & Composition */}
        <div className="flex-1 overflow-y-auto">
             {renderParameters()}
        </div>

        {/* Connections */}
        <div className="space-y-4 pt-2 border-t border-slate-700/50">
            {rules.maxInputs > 0 && (
                <div>
                    <h4 className="text-sm font-semibold text-gray-300 mb-2">Inputs ({inputs.length}/{isFinite(rules.maxInputs) ? rules.maxInputs : '∞'})</h4>
                    <div className="space-y-1">
                        {inputs.map(edge => (
                            <div key={edge.id} className="flex items-center justify-between bg-slate-700/50 p-2 rounded-md">
                                <span className="text-sm">{getNodeName(edge.from)}</span>
                                <button onClick={() => onRemoveEdge(edge.id)} className="text-gray-400 hover:text-red-400">
                                    <TrashIcon className="w-4 h-4" />
                                </button>
                            </div>
                        ))}
                        {inputs.length === 0 && <p className="text-xs text-gray-500 px-2">No inputs</p>}
                    </div>
                    {canAddInput && (
                        <select 
                            value={selectedInputToAdd}
                            onChange={handleAddInput} 
                            className="mt-2 w-full bg-slate-700 border border-slate-600 rounded-md px-3 py-1.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        >
                            <option value="">Add Input From...</option>
                            {availableInputNodes.map(n => (
                                <option key={n.id} value={n.id}>{n.name}</option>
                            ))}
                        </select>
                    )}
                </div>
            )}

            {rules.maxOutputs > 0 && (
                <div>
                    <h4 className="text-sm font-semibold text-gray-300 mb-2">Outputs ({outputs.length}/{isFinite(rules.maxOutputs) ? rules.maxOutputs : '∞'})</h4>
                    <div className="space-y-1">
                        {outputs.map(edge => (
                        <div
                            key={edge.id}
                            className="flex items-center justify-between bg-slate-700/50 p-2 rounded-md"
                        >
                            <div className="flex items-center gap-2 flex-1">
                            <span className="text-sm">{getNodeName(edge.to)}</span>

                            {isSplitter && (
                                <div className="flex items-center gap-2 ml-auto">
                                <span className="text-xs text-gray-400">Split</span>
                                <input
                                    type="number"
                                    step="0.01"
                                    min="0"
                                    max="1"
                                    value={splitRatios[edge.to] ?? 0}
                                    onChange={(e) => handleSplitRatioChange(edge.to, e.target.value)}
                                    className="w-20 bg-slate-800 border border-slate-600 rounded px-2 py-1 text-xs text-right text-white"
                                />
                                </div>
                            )}
                            </div>

                            <button
                            onClick={() => handleRemoveOutputEdge(edge.id, edge.to)}
                            className="text-gray-400 hover:text-red-400 ml-2"
                            >
                            <TrashIcon className="w-4 h-4" />
                            </button>
                        </div>
                        ))}

                        {outputs.length === 0 && <p className="text-xs text-gray-500 px-2">No outputs</p>}
                    </div>
                    {canAddOutput && (
                        <select 
                            value={selectedOutputToAdd}
                            onChange={handleAddOutput} 
                            className="mt-2 w-full bg-slate-700 border border-slate-600 rounded-md px-3 py-1.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        >
                            <option value="">Add Output To...</option>
                            {availableOutputNodes.map(n => (
                                <option key={n.id} value={n.id}>{n.name}</option>
                            ))}
                        </select>
                    )}
                </div>
            )}
        </div>
    </div>
  );
};

export default PropertiesPanel;
