import React, { useState, useEffect, useRef } from 'react';
import {
  Project,
  ChatMessage,
  FlowsheetNode,
  FlowsheetEdge,
  EquipmentType,
} from '../types';
import Chatbot from './Chatbot';
import FlowDiagram from './FlowDiagram';
import ResultTable from './ResultTable';
import SaveIcon from './icons/SaveIcon';
import { dbService } from '../services/db';

interface MainContentProps {
  project: Project;
  onUpdateProject: (id: string, data: Partial<Project>) => void;
}

type Tab = 'chat' | 'flow-diagram' | 'result-table';

// Helper to map JSON parameter keys
const mapParamKey = (key: string): string => {
  const map: Record<string, string> = {
    Temperature: 'temperature',
    Pressure: 'pressure',
    'Outlet Temperature': 'outletTemperature',
    'Outlet Pressure': 'outletPressure',
    Stages: 'stages',
    'Condenser Type': 'condenserType',
    'Reflux Ratio': 'refluxRatio',
  };

  if (map[key]) return map[key];

  return key
    .replace(/(?:^\w|[A-Z]|\b\w)/g, (word, index) =>
      index === 0 ? word.toLowerCase() : word.toUpperCase(),
    )
    .replace(/\s+/g, '');
};

const MainContent: React.FC<MainContentProps> = ({ project, onUpdateProject }) => {
  const [projectName, setProjectName] = useState(project.name);
  const [activeTab, setActiveTab] = useState<Tab>('chat');
  const [messages, setMessages] = useState<ChatMessage[]>(project.messages || []);
  const [nodes, setNodes] = useState<FlowsheetNode[]>(project.nodes || []);
  const [edges, setEdges] = useState<FlowsheetEdge[]>(project.edges || []);
  const [results, setResults] = useState<any[]>(project.results || []);

  const processedMessageIds = useRef<Set<string>>(
    new Set((project.messages || []).map(m => m.id)),
  );

  // Sync with project prop
  useEffect(() => {
    setProjectName(project.name);
    setMessages(project.messages || []);
    setNodes(project.nodes || []);
    setEdges(project.edges || []);
    setResults(project.results || []);

    const currentIds = new Set((project.messages || []).map(m => m.id));
    currentIds.forEach(id => processedMessageIds.current.add(id));
  }, [project]);

  // Automatic Flowsheet Parsing
  useEffect(() => {
    if (messages.length === 0) return;

    const startIndex = Math.max(0, messages.length - 3);
    const recentMessages = messages.slice(startIndex);

    recentMessages.forEach(msg => {
      if (processedMessageIds.current.has(msg.id)) return;
      if (msg.isTyping || !msg.text) return;

      if (msg.text.includes('Equipment_list') && msg.text.includes('Connection')) {
        processedMessageIds.current.add(msg.id);
        void attemptParseAndGenerate(msg.text);
      }
    });
  }, [messages]);

  const attemptParseAndGenerate = async (text: string) => {
    try {
      let jsonString = text;

      const codeBlockMatch =
        text.match(/``````/) ||
        text.match(/``````/);

      if (codeBlockMatch) {
        jsonString = codeBlockMatch[1];
      } else {
        const firstOpen = text.indexOf('{');
        const lastClose = text.lastIndexOf('}');
        if (firstOpen !== -1 && lastClose !== -1 && lastClose > firstOpen) {
          jsonString = text.substring(firstOpen, lastClose + 1);
        }
      }

      const data = JSON.parse(jsonString);

      if (data.Equipment_list && data.Connection) {
        // Backend builds flowsheet (nodes, edges, layout)
        const fsData = await dbService.generateFlowsheetFromBackend(data);

        const backendNodes: FlowsheetNode[] = (fsData.nodes || []).map((n: any) => ({
          id: n.id,
          type: n.type as EquipmentType,
          name: n.name,
          x: n.x ?? 0,
          y: n.y ?? 0,
          properties: n.properties || {},
        }));

        const backendEdges: FlowsheetEdge[] = (fsData.edges || []).map((e: any) => ({
          id: e.id,
          from: e.from_ ?? e.from,
          to: e.to,
        }));

        setNodes(backendNodes);
        setEdges(backendEdges);
        setActiveTab('flow-diagram');

        setMessages(prev => {
          if (prev[prev.length - 1]?.text === 'Flowsheet generated successfully.') {
            return prev;
          }
          return [
            ...prev,
            {
              id: 'sys-' + Date.now().toString(),
              sender: 'ai',
              text: 'Flowsheet generated successfully.',
            },
          ];
        });
      }
    } catch (e) {
      console.debug('Failed to parse JSON or generate flowsheet', e);
    }
  };

  const handleSave = () => {
    onUpdateProject(project.id, {
      name: projectName,
      messages,
      nodes,
      edges,
      results,
    });
  };

  const handleRunSimulation = async () => {
    const currentProjectState: Project = {
      ...project,
      nodes,
      edges,
      properties: {},
    } as any;

    const simulationResults = await dbService.runSimulation(
      project.id,
      currentProjectState,
    );

    setResults(simulationResults);
    onUpdateProject(project.id, { results: simulationResults });
    setActiveTab('result-table');
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'chat':
        return (
          <Chatbot
            project={project}
            messages={messages}
            setMessages={setMessages}
          />
        );
      case 'flow-diagram':
        return (
          <FlowDiagram
            nodes={nodes}
            edges={edges}
            setNodes={setNodes}
            setEdges={setEdges}
            onRunSimulation={handleRunSimulation}
          />
        );
      case 'result-table':
        return <ResultTable data={results} />;
      default:
        return null;
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-900 text-slate-100">
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800">
        <input
          type="text"
          value={projectName}
          onChange={e => setProjectName(e.target.value)}
          className="text-lg font-semibold bg-transparent border-none text-white focus:ring-0 -ml-1"
          placeholder="Project Name"
        />
        <button
          onClick={handleSave}
          className="inline-flex items-center px-3 py-1.5 rounded-md bg-indigo-600 text-white text-sm font-medium hover:bg-indigo-500"
        >
          <SaveIcon className="w-4 h-4 mr-1.5" />
          Save
        </button>
      </div>

      <div className="flex flex-col h-full">
        <div className="flex space-x-1 px-4 pt-3 bg-slate-900">
          {(['chat', 'flow-diagram', 'result-table'] as Tab[]).map(t => (
            <button
              key={t}
              onClick={() => setActiveTab(t)}
              className={`px-4 py-2 text-sm font-medium rounded-t-md transition-colors ${
                activeTab === t
                  ? 'bg-slate-800 text-white border-b-2 border-indigo-500'
                  : 'text-gray-400 hover:bg-slate-700/50'
              }`}
            >
              {t
                .replace('-', ' ')
                .replace(/\b\w/g, c => c.toUpperCase())}
            </button>
          ))}
        </div>

        <div className="flex-1 bg-slate-950 border-t border-slate-800 p-4 overflow-hidden">
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
};

export default MainContent;
