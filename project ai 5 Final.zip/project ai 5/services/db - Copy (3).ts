// frontend/src/services/db.ts
import { Project } from "../types";

const API_BASE_URL = "http://127.0.0.1:8000";
const API_TIMEOUT_MS = 3000;
const LOCAL_STORAGE_KEY = "ai_process_sim_projects";

const getLocalProjects = (): Project[] => {
  try {
    const stored = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (!stored) return [];
    const parsed = JSON.parse(stored);
    return Array.isArray(parsed) ? (parsed as Project[]) : [];
  } catch (error) {
    console.error("Failed to read local storage:", error);
    return [];
  }
};

const saveLocalProjects = (projects: Project[]) => {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(projects));
  } catch (error) {
    console.error("Failed to save to local storage:", error);
  }
};

const fetchWithTimeout = async (url: string, options: RequestInit = {}) => {
  const controller = new AbortController();
  const id = window.setTimeout(() => controller.abort(), API_TIMEOUT_MS);

  try {
    const response = await fetch(url, { ...options, signal: controller.signal });
    window.clearTimeout(id);
    return response;
  } catch (error) {
    window.clearTimeout(id);
    throw error;
  }
};

const dbService = {
  async getAllProjects(): Promise<Project[]> {
    try {
      const response = await fetchWithTimeout(`${API_BASE_URL}/projects`, { method: "GET" });
      if (!response.ok) throw new Error(`API error: ${response.status}`);
      const projects = (await response.json()) as Project[];
      saveLocalProjects(projects);
      return projects;
    } catch (error) {
      console.warn("API not reachable, using local projects.", error);
      return getLocalProjects();
    }
  },

  async saveProject(project: Project): Promise<void> {
    // local save first
    const projects = getLocalProjects();
    const index = projects.findIndex((p) => p.id === project.id);
    if (index >= 0) projects[index] = project;
    else projects.push(project);
    saveLocalProjects(projects);

    // api save
    try {
      const response = await fetchWithTimeout(`${API_BASE_URL}/projects/${project.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(project),
      });
      if (!response.ok) throw new Error(`Save failed: ${response.status}`);
    } catch (e) {
      console.warn("API Save failed (kept locally).", e);
    }
  },

  async deleteProject(projectId: string): Promise<void> {
    // local delete first
    const projects = getLocalProjects().filter((p) => p.id !== projectId);
    saveLocalProjects(projects);

    // api delete
    try {
      const response = await fetchWithTimeout(`${API_BASE_URL}/projects/${projectId}`, {
        method: "DELETE",
      });
      if (!response.ok) throw new Error(`Delete failed: ${response.status}`);
    } catch (e) {
      console.warn("API Delete failed (removed locally).", e);
    }
  },

  async getChemicals(): Promise<string[]> {
    const res = await fetch(`${API_BASE_URL}/chemicals`, { method: "GET" });
    if (!res.ok) {
      throw new Error(`Failed to fetch chemicals: ${res.status} ${res.statusText}`);
    }
    // backend returns string[]
    return (await res.json()) as string[];
  },

  async uploadFile(projectId: string, file: File): Promise<string> {
    const formData = new FormData();
    formData.append("file", file); // must match FastAPI param name: "file"

    const response = await fetch(`${API_BASE_URL}/projects/${projectId}/upload`, {
      method: "POST",
      body: formData,
    });

    if (!response.ok) {
      // backend may return JSON detail or plain text
      let msg = "Upload failed";
      try {
        const err = await response.json();
        msg = err?.detail ?? msg;
      } catch {
        msg = await response.text();
      }
      throw new Error(msg);
    }

    const data = await response.json();
    return data.filename ?? data.name ?? file.name;
  },

  // Used by MainContent.tsx
  async generateFlowsheetFromBackenddata(data: any): Promise<any> {
    const res = await fetch(`${API_BASE_URL}/generateflowsheet`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Failed to generate flowsheet: ${res.status} ${text}`);
    }

    return await res.json(); // { nodes: [...], edges: [...] }
  },

  // Used by MainContent.tsx
  async runSimulation(projectId: string, projectState: Project): Promise<any> {
    const res = await fetch(`${API_BASE_URL}/projects/${projectId}/run`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(projectState),
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Simulation failed: ${res.status} ${text}`);
    }

    return await res.json();
  },

  // Optional: call the datatable-style endpoint if you switch UI to /simulate later
  async simulateDatatable(projectId: string, streams: any): Promise<any> {
    const res = await fetch(`${API_BASE_URL}/projects/${projectId}/simulate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ streams }),
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Simulation failed: ${res.status} ${text}`);
    }

    return await res.json();
  },
};

export default dbService;
export { dbService };
