
// // import { Project } from '../types';

// // const API_URL = 'http://localhost:8000';
// // const LOCAL_STORAGE_KEY = 'ai_process_sim_projects';
// // const API_TIMEOUT_MS = 3000;
// // const API_BASE_URL = 'http://127.0.0.1:8000';

// // // Helper to safe-read local storage
// // const getLocalProjects = (): Project[] => {
// //     try {
// //         const stored = localStorage.getItem(LOCAL_STORAGE_KEY);
// //         if (!stored) return [];
// //         const parsed = JSON.parse(stored);
// //         return Array.isArray(parsed) ? parsed : [];
// //     } catch (error) {
// //         console.error("Failed to read local storage:", error);
// //         return [];
// //     }
// // };

// // const saveLocalProjects = (projects: Project[]) => {
// //     try {
// //         localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(projects));
// //     } catch (error) {
// //         console.error("Failed to save to local storage:", error);
// //     }
// // };

// // const fetchWithTimeout = async (url: string, options: RequestInit = {}) => {
// //     const controller = new AbortController();
// //     const id = setTimeout(() => controller.abort(), API_TIMEOUT_MS);
// //     try {
// //         const response = await fetch(url, {
// //             ...options,
// //             signal: controller.signal
// //         });
// //         clearTimeout(id);
// //         return response;
// //     } catch (error) {
// //         clearTimeout(id);
// //         throw error;
// //     }
// // };

// // // export const dbService = {
// // //   async getAllProjects(): Promise<Project[]> {
// // //     try {
// // //         const response = await fetchWithTimeout(`${API_URL}/projects`);
// // //         if (!response.ok) throw new Error("API Error");
// // //         const projects = await response.json();
// // //         saveLocalProjects(projects);
// // //         return projects;
// // //     } catch (error) {
// // //         return getLocalProjects();
// // //     }
// // //   },

// // export const dbService = {
// //   async getChemicals(): Promise<string[]> {
// //     const res = await fetch(`${API_BASE_URL}/chemicals`, {
// //       method: 'GET',
// //     });
// //     if (!res.ok) {
// //       throw new Error(`Failed to fetch chemicals: ${res.statusText}`);
// //     }
// //     // Expecting backend to return: { chemicals: ["Methane", "Ethane", ...] }
// //     const data = await res.json();
// //     return data.chemicals || [];
// //   },

// //   async saveProject(project: Project): Promise<void> {
// //     // Local save first
// //     const projects = getLocalProjects();
// //     const index = projects.findIndex(p => p.id === project.id);
// //     if (index >= 0) projects[index] = project;
// //     else projects.push(project);
// //     saveLocalProjects(projects);

// //     // API save
// //     try {
// //         await fetchWithTimeout(`${API_URL}/projects/${project.id}`, {
// //             method: 'PUT',
// //             headers: { 'Content-Type': 'application/json' },
// //             body: JSON.stringify(project),
// //         });
// //     } catch (e) {
// //         console.warn("API Save failed, data saved locally.");
// //     }
// //   },

// //   async deleteProject(id: string): Promise<void> {
// //     // Local delete
// //     const projects = getLocalProjects();
// //     const filtered = projects.filter(p => p.id !== id);
// //     saveLocalProjects(filtered);

// //     // API delete
// //     try {
// //         await fetchWithTimeout(`${API_URL}/projects/${id}`, { method: 'DELETE' });
// //     } catch (e) {
// //         console.warn("API Delete failed");
// //     }
// //   },
  
// //   async getChemicals(): Promise<string[]> {
// //       try {
// //           const response = await fetchWithTimeout(`${API_URL}/chemicals`);
// //           if (response.ok) return await response.json();
// //       } catch (e) {}
// //       return ["Water", "Ethanol", "Methanol", "Oxygen", "Nitrogen", "Carbon Dioxide", "Hydrogen"];
// //   },

// //   async uploadFile(projectId: string, file: File): Promise<string> {
// //       const formData = new FormData();
// //       formData.append('file', file);
      
// //       try {
// //           const response = await fetch(`${API_URL}/projects/${projectId}/upload`, {
// //               method: 'POST',
// //               body: formData
// //           });
// //           if (!response.ok) throw new Error("Upload failed");
// //           const data = await response.json();
// //           return data.filename;
// //       } catch (e) {
// //           console.error(e);
// //           throw e;
// //       }
// //   },
// //   async runSimulation(projectId: string, projectState: Project): Promise<any[]> {
// //     const res = await fetch(`${API_BASE_URL}/run_simulation`, {
// //       method: 'POST',
// //       headers: {
// //         'Content-Type': 'application/json',
// //       },
// //       // Send the flowsheet, nodes, edges, etc. Backend main.py should parse this.
// //       body: JSON.stringify({
// //         project_id: projectId,
// //         project: projectState,
// //       }),
// //     });

// //     if (!res.ok) {
// //       const text = await res.text();
// //       throw new Error(`Simulation failed: ${res.status} ${text}`);
// //     }

// //     // Expecting backend to return: { results: [ { col1: ..., col2: ... }, ... ] }
// //     const data = await res.json();
// //     return data.results || data; // support both wrapped and direct list
// //   },
// // };

// // //   async runSimulation(projectId: string, project: Project): Promise<any[]> {
// // //       try {
// // //           // We send the full project state to be simulated
// // //           const response = await fetch(`${API_URL}/projects/${projectId}/run`, {
// // //               method: 'POST',
// // //               headers: { 'Content-Type': 'application/json' },
// // //               body: JSON.stringify(project)
// // //           });
// // //           if (!response.ok) throw new Error("Simulation failed");
// // //           return await response.json();
// // //       } catch (e) {
// // //           console.error("Backend run failed, fallback not implemented for generic results", e);
// // //           return [{ Error: "Backend not reachable for simulation" }];
// // //       }
// // //   }
// // // };

// // frontend/src/services/db.ts
// import { Project } from '../types';

// const API_BASE_URL = 'http://127.0.0.1:8000'; // or whatever port main.py uses

// export const dbService = {

//   async getChemicals(): Promise<string[]> {
//     const res = await fetch(`${API_BASE_URL}/chemicals`, {
//       method: 'GET',
//     });
//     if (!res.ok) {
//       throw new Error(`Failed to fetch chemicals: ${res.statusText}`);
//     }
//     // Expecting backend to return: { chemicals: ["Methane", "Ethane", ...] }
//     const data = await res.json();
//     return data.chemicals || [];
//   },

//   async uploadFile(projectId: string, file: File): Promise<string> {
//   const formData = new FormData();
//   formData.append('file', file); // MUST be 'file' (matches FastAPI param)
//   const res = await fetch(`${API_BASE_URL}/projects/${projectId}/upload`, {
//     method: 'POST',
//     body: formData,
//   });
//   if (!res.ok) throw new Error('Upload failed');
//   const data = await res.json();
//   return data.name ?? data.filename; // backend currently returns filename
// },


//   async runSimulation(projectId: string, projectState: Project): Promise<any[]> {
//     const res = await fetch(`${API_BASE_URL}/run_simulation`, {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//       },
//       // Send the flowsheet, nodes, edges, etc. Backend main.py should parse this.
//       body: JSON.stringify({
//         project_id: projectId,
//         project: projectState,
//       }),
//     });

//     if (!res.ok) {
//       const text = await res.text();
//       throw new Error(`Simulation failed: ${res.status} ${text}`);
//     }

//     // Expecting backend to return: { results: [ { col1: ..., col2: ... }, ... ] }
//     const data = await res.json();
//     return data.results || data; // support both wrapped and direct list
//   },
//   async generateFlowsheetFromBackend(data: any) {
//     const res = await fetch(`${API_BASE_URL}/generate_flowsheet`, {
//       method: 'POST',
//       headers: { 'Content-Type': 'application/json' },
//       body: JSON.stringify(data),
//     });
//     if (!res.ok) {
//       throw new Error(`Failed to generate flowsheet: ${res.statusText}`);
//     }
//     return res.json(); // { nodes: [...], edges: [...] }
//   },
// };

// frontend/src/services/db.ts
import { Project } from '../types';

const API_BASE_URL = 'http://127.0.0.1:8000';

export const dbService = {
  // async getChemicals(): Promise<string[]> {
  //   const res = await fetch(`${API_BASE_URL}/chemicals`, { method: 'GET' });
  //   if (!res.ok) {
  //     throw new Error(`Failed to fetch chemicals: ${res.status} ${res.statusText}`);
  //   }
  //   // backend returns List[str], so res.json() is string[]
  //   return await res.json();
  // },
  async getChemicals(): Promise<string[]> {
  const res = await fetch(`${API_BASE_URL}/chemicals`, { method: 'GET' });
  if (!res.ok) {
    throw new Error(`Failed to fetch chemicals: ${res.status} ${res.statusText}`);
  }
  return await res.json(); // backend returns string[]
}

  // async uploadFile(projectId: string, file: File): Promise<string> {
  //   const formData = new FormData();
  //   formData.append('file', file); // must match FastAPI parameter name: file

  //   const res = await fetch(`http://127.0.0.1:8000/projects/${projectId}/upload`, {
  //     method: 'POST',
  //     body: formData,
  //   });

  //   if (!res.ok) {
  //     const text = await res.text();
  //     throw new Error(`Upload failed: ${res.status} ${text}`);
  //   }

  //   const data = await res.json();
  //   return data.filename ?? file.name;
  // },

  async uploadFile(projectId: string, file: File): Promise<string> {
    const formData = new FormData();
    formData.append('file', file);
    
    const response = await fetch(`${API_BASE_URL}/projects/${projectId}/upload`, {
        method: 'POST',
        body: formData
    });
    
    if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || "Upload failed");
    }
    
    const data = await response.json();
    return data.filename;
  },


  async runSimulation(projectId: string, projectState: Project): Promise<any> {
    const res = await fetch(`${API_BASE_URL}/projects/${projectId}/run`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(projectState),
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Simulation failed: ${res.status} ${text}`);
    }

    return await res.json();
  },

  async generateFlowsheetFromBackend(data: any) {
    const res = await fetch(`${API_BASE_URL}/generate_flowsheet`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Failed to generate flowsheet: ${res.status} ${text}`);
    }

    return await res.json(); // { nodes: [...], edges: [...] }
  },
};
