import re
import json
import os
import ast
from typing import TypedDict, Sequence, Annotated
from pydantic import BaseModel, Field
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, ToolMessage, SystemMessage
from langchain_core.tools import tool
from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings
from langchain_community.document_loaders import PyPDFLoader
# from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough ,RunnableLambda
from langchain_core.output_parsers import StrOutputParser
from langgraph.graph import StateGraph, END, START
from langgraph.prebuilt import ToolNode
from graphviz import Digraph
import uuid
import pandas as pd
from pathlib import Path


API_KEY = 'AIzaSyCdz6n34Hj3F-MMGbBrGdsBY1HkMDEXcyQ'
# API_KEY ="AIzaSyBDQUbwwapACKQp1Kvx-ydW71m3TespwE4"
# PDF_PATH = 'The ethylbenzene production.pdf'
gemini_model ="gemini-2.5-flash-lite"

# Initialize Google Generative AI components
embeddings = GoogleGenerativeAIEmbeddings(
    model="models/text-embedding-004",
    google_api_key=API_KEY
)

llm = ChatGoogleGenerativeAI(
    model=gemini_model,
    google_api_key=API_KEY,
    temperature=0.7,
    max_tokens=None,
    timeout=None,
    max_retries=2,
)

Data_proces_prompt = """
You are a chemical process flowsheet parser.check the user request and get the data from the context
where make sure that if the user requested information are in the context or in the chat history .if none of the have the return a json of the following structure 
{"Data":"Not available"}
 if the data is available  

Convert the user’s process description into only one valid JSON object (no markdown, no code fences, no extra text).

Allowed equipment types (type must match exactly)
Feed, Tank, Heater, Cooler, Pump, Compressor, Expander, HeatExchanger, Reactor, Flash, DistillationColumn, Mixer, Splitter, Product

Output schema (exact top-level keys)
"Equipment_list": array in process-flow order, items: { "<id>": "<type>" }

"Connection": array same length and same order as "Equipment_list", items:
{ "equipment": "<id>", "outlet": ["<downstream_id>", ...], "Param": { ... } }

Naming + connection rules
IDs are sequential per type: Feed_1, Feed_2, Heater_1, Product_1, etc.

Create only equipment implied by the user. If the user ends a path with “product/outlet”, create Product nodes for each terminal outlet.

Product must have "outlet": []. Feed is a source (no inlet concept needed).

All outlet IDs must exist in "Equipment_list".

Param rules (omit unknown keys; do not use null/empty strings)
Feed Param keys:

"Temperature" (K), default 298 if missing

"Pressure" (bar), default 1 if missing

"Flow Rate" (kmol/hr), default 100 if missing

"Compounds": [{"name": string, "moleFraction": number}, ...]
If compounds are given, mole fractions must sum to 1.0 (normalize if needed). If no composition is provided, omit "Compounds" entirely (do not invent chemicals).

Unit Param keys (include only if user explicitly provides):

Tank / Flash / Reactor: "Temperature", "Pressure"

Heater / Cooler / HeatExchanger: "Outlet Temperature"

Pump / Compressor / Expander: "Outlet Pressure"

Mixer: {} always

Product: {} always

Splitter: "Split Ratio": { "<outlet_id>": frac, ... } (keys must match its "outlet" list; sum to 1.0; if unspecified assume equal split)

DistillationColumn: "Stages", "Condenser Type" ("Total" or "Partial"), "Reflux Ratio", "Pressure"
Defaults only if user explicitly requests “default/typical”: Stages=20, Condenser Type="Total", Reflux Ratio=1.5.

Validation
JSON must be syntactically valid.

"Equipment_list" order aligns with "Connection" order.

Positive
T
,
P
T,P when present.

Fractions/ratios sum to 1.0 when present.

Reference example (structure)
{
"Equipment_list": {
"Feed_1: "Feed" ,
"Heater_1" : "Heater" ,
"Splitter_1": "Splitter" ,
 "Product_1": "Product" ,
 "Product_2": "Product" }
,
"Connection": [
{
"equipment": "Feed_1",
"outlet": ["Heater_1"],
"Param": {
"Temperature": 298,
"Pressure": 1,
"Flow Rate": 100,
"Compounds": [
{ "name": "Methane", "moleFraction": 0.7 },
{ "name": "Ethane", "moleFraction": 0.3 }
]
}
},
{
"equipment": "Heater_1",
"outlet": ["Splitter_1"],
"Param": { "Outlet Temperature": 350 }
},
{
"equipment": "Splitter_1",
"outlet": ["Product_1", "Product_2"],
"Param": { "Split Ratio": { "Product_1": 0.5, "Product_2": 0.5 } }
},
{ "equipment": "Product_1", "outlet": [], "Param": {} },
{ "equipment": "Product_2", "outlet": [], "Param": {} }
]
}
"""


def simulation_generator(projectid,chat_history):


    BASE_DIR = Path(__file__).resolve().parent
    persist_directory = (BASE_DIR / "rag_db" / str(projectid))
    vector_store = Chroma(persist_directory=str(persist_directory), embedding_function=embeddings)
    retriever = vector_store.as_retriever(search_kwargs={"k": 3})

    simulation_temp="""
You are a chemical process flowsheet parser.check the user request and get the data from the context

Task:
1) Read the user request.
2) Extract required data ONLY from the provided Context and chat_ref.
3) If the required data is missing from BOTH Context and chat_ref, return ONLY this JSON:
{"Data":"Not available"}

If the data is available, return ONLY one valid JSON object (no markdown, no code fences, no extra text).
Return STRICT JSON:
- Use double quotes for all keys/strings.
- Do NOT use Python single quotes.

Make sure all the simualtion starts with feed 
and a equipment can not be without any input connection it can be connected to other equipment or it can be connected to a feed except feed
if a equipment does not have any info about the feed stream , add the chemicals and use the 25C and 1 bar as the feed condition 
and similary equipment should not be end witout any ending connection , it should be connected to other equipment or then it should be connected to product stream 
Allowed equipment types (type must match exactly):
Feed, Tank, Heater, Cooler, Pump, Compressor, Expander, HeatExchanger, Reactor, Flash, DistillationColumn, Mixer, Splitter, Product

REQUIRED OUTPUT SCHEMA (top-level keys must match exactly):

1) "Equipment_list" MUST be a JSON OBJECT (dictionary/map), NOT an array/list.
   - It maps equipment id -> equipment type.
   - Example shape:
     "Equipment_list": {
       "Feed_1": "Feed",
       "Heater_1": "Heater"
     }

2) "Connection" MUST be an array with one entry per equipment item.
   - Each item shape:
     { "equipment": "<id>", "outlet": ["<downstream_id>", ...], "Param": { ... } }

Naming rules:
- IDs are sequential per type: Feed_1, Feed_2, Heater_1, Product_1, etc.
- Create only equipment implied by the user.
- If the user ends a path with “product/outlet”, create Product nodes for each terminal outlet.
- Product must have "outlet": [].
- All outlet IDs must exist as keys in "Equipment_list".

Param rules (omit unknown keys; do not use null/empty strings):
Feed Param keys:
- "temperature" (K), default 298 if missing
- "pressure" (bar), default 1 if missing
- "flowRate" (kmol/hr), default 100 if missing
- "compounds": [{"name": string, "moleFraction": number}, ...]
  If compounds are given, mole fractions must sum to 1.0 (normalize if needed).
  If no composition is provided, omit "Compounds" entirely.

Unit Param keys (include only if user explicitly provides):
- Tank / Flash / Reactor: "temperature", "pressure"
- Heater / Cooler / HeatExchanger: "outletTemperature"
- Pump / Compressor / Expander: "outletPressure"
- Mixer: {} always
- Product: {} always
- Splitter: "splitRatios": { "<outlet_id>": frac, ... } (sum to 1.0; if unspecified assume equal split)
- DistillationColumn: "stages", "condenserType" ("Total" or "Partial"), "refluxRatio", "Pressure"
  Defaults only if user explicitly requests “default/typical”: stages=20, Condenser Type="Total", Reflux Ratio=1.5.

Validation:
- JSON must be syntactically valid.
- Each "Connection[i].equipment" must be a key in "Equipment_list".
- Fractions/ratios sum to 1.0 when present.
- Temperatures/pressures/flows must be positive when present.

Reference example (structure only):
{
"Equipment_list": {
"Feed_1": "Feed",
"Heater_1": "Heater",
"Splitter_1": "Splitter",
"Product_1": "Product",
"Product_2": "Product"
},
"Connection": [
{
"equipment": "Feed_1",
"outlet": ["Heater_1"],
"Param": {
"Temperature": 298,
"Pressure": 1,
"Flow Rate": 100,
"Compounds": [
{ "name": "Methane", "moleFraction": 0.7 },
{ "name": "Ethane", "moleFraction": 0.3 }
]
}
},
{ "equipment": "Heater_1", "outlet": ["Splitter_1"], "Param": { "Outlet Temperature": 350 } },
{ "equipment": "Splitter_1", "outlet": ["Product_1", "Product_2"], "Param": { "Split Ratio": { "Product_1": 0.5, "Product_2": 0.5 } } },
{ "equipment": "Product_1", "outlet": [], "Param": {} },
{ "equipment": "Product_2", "outlet": [], "Param": {} }
]
}""".strip()


    # prompt = ChatPromptTemplate.from_template(
    #
    # Question: {question}
    # Context: {context}
    # chat_ref:{chat_ref}
    # Answer:
    # """)

    prompt = ChatPromptTemplate.from_messages([
        SystemMessage(content=simulation_temp),
        ("human", "Question: {question}\nContext: {context}\nchat_ref: {chat_ref}\nAnswer:")
    ])

    def format_docs(docs):
        return "\n\n".join(doc.page_content for doc in docs)

    rag_chain = (
            {
                "context": retriever | format_docs,
                "question": RunnablePassthrough(),
                "chat_ref": RunnableLambda(lambda _: chat_history),
            }
            | prompt
            | llm
            | StrOutputParser()
    )



    # rag_chain = (
    #         {"context": retriever | format_docs, "question": RunnablePassthrough(), "chat_ref":RunnableLambda(lambda x: chat_history) }
    #         | prompt
    #         | llm
    #         | StrOutputParser()
    # )

    return rag_chain







