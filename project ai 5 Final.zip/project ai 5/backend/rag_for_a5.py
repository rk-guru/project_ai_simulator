import re
import json
import os
import ast
from typing import TypedDict, Sequence, Annotated
from pydantic import BaseModel, Field
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, ToolMessage, SystemMessage
from langchain_core.tools import tool
from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings
from langchain_community.document_loaders import PyPDFLoader
# from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough ,RunnableLambda
from langchain_core.output_parsers import StrOutputParser
from langgraph.graph import StateGraph, END, START
from langgraph.prebuilt import ToolNode
from graphviz import Digraph
import uuid
import pandas as pd
from pathlib import Path
import time





API_KEY = 'AIzaSyCdz6n34Hj3F-MMGbBrGdsBY1HkMDEXcyQ'#'AIzaSyDsRutviDquMkxuPu2Eq8r2F-HktuGraaQ'
# PDF_PATH = 'The ethylbenzene production.pdf'
# API_KEY ="AIzaSyBDQUbwwapACKQp1Kvx-ydW71m3TespwE4"
gemini_model ="gemini-2.5-flash-lite"

# Initialize Google Generative AI components
embeddings = GoogleGenerativeAIEmbeddings(
    model="models/text-embedding-004",
    google_api_key=API_KEY
)

llm = ChatGoogleGenerativeAI(
    model=gemini_model,
    google_api_key=API_KEY,
    temperature=0.7,
    max_tokens=None,
    timeout=None,
    max_retries=2,
)

# def project_file_rag(projectid,file_name):
#     """Sets up a RAG chain by loading a PDF and creating a ChromaDB vector store."""
#     # time.sleep(5)
#     db_name = Path(f'./ragh_db/{projectid}')
#     persist_directory = db_name
#     pdf_path=Path(f'./uploads/{projectid}/{file_name}')
#
#
#     # if os.path.isfile(pdf_path):
#     #     print("File exists.")
#     # else:
#     #     print("File does not exist.")
#     print('persist_directory=',persist_directory)
#     print('pdf_path=',pdf_path)
#
#     # if not os.path.exists(persist_directory) or not os.listdir(persist_directory):
#     print(f"Creating a new RAG vector store for '{db_name}'...")
#     try:
#         loader = PyPDFLoader(f'./uploads/{projectid}/{file_name}')
#         print(loader)
#         docs = loader.load()
#         print('docs',docs)
#         text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
#         print('text')
#         splits = text_splitter.split_documents(docs)
#         print('splites',splits)
#
#         vector_store = Chroma.from_documents(
#             documents=splits,
#             embedding=embeddings,
#             persist_directory=persist_directory
#         )
#         print(f"Vector store created at '{persist_directory}'.")
#     except Exception as e:
#         print(f"Error creating vector store: {e}")
#         return None
#
#     from pathlib import Path

def project_file_rag(projectid, file_name):
    # 1) Validate inputs early
    # if not projectid or str(projectid).lower() == "undefined":
    #     raise ValueError(f"Invalid projectid: {projectid!r}")
    #
    # if not file_name:
    #     raise ValueError("file_name is empty")

    BASE_DIR = Path(__file__).resolve().parent  # adjust if needed

    persist_directory = (BASE_DIR / "rag_db" / str(projectid))
    pdf_path = (BASE_DIR / "uploads" / str(projectid) / file_name)

    print("persist_directory =", persist_directory)
    print("pdf_path =", pdf_path)

    # 2) Ensure directories/files exist
    persist_directory.mkdir(parents=True, exist_ok=True)

    # if not pdf_path.is_file():
    #     raise FileNotFoundError(f"PDF not found at: {pdf_path}")

    # 3) Load + split + store
    loader = PyPDFLoader(str(pdf_path))  # PyPDFLoader usage expects a file path string [page:1]
    print('loader',loader)
    docs = loader.load()
    print('docs',docs)

    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    splits = text_splitter.split_documents(docs)
    print('splits',splits)

    vector_store = Chroma.from_documents(
        documents=splits,
        embedding=embeddings,
        persist_directory=str(persist_directory),
    )
    return vector_store


def chat_with_rag(projectid ,last_10_chat):
    BASE_DIR = Path(__file__).resolve().parent
    persist_directory = (BASE_DIR / "rag_db" / str(projectid))
    vector_store = Chroma(persist_directory=str(persist_directory),embedding_function=embeddings)
    retriever = vector_store.as_retriever(search_kwargs={"k": 3})
    prompt = ChatPromptTemplate.from_template("""
    Consider you are a chemical engineering assistant . you need to answer the question in the following format.
    If you are answering based on the context (ragged data). also specify the reference info including the file name .
    If the question is not related to chemical , chemical engineering or bio response only by saying "Sorry, i can respond only for chemical engineering questions"
    the chat reference is used to show the last 10 chat between ai and human from reference , it is shown in list format 
        
    Question: {question}
    Context: {context}
    chat_ref:{chat_ref}
    Answer:
    """)

    def format_docs(docs):
        return "\n\n".join(doc.page_content for doc in docs)

    def format_docs2(docs):
        return "\n\n".join(doc for doc in docs)

    rag_chain = (
            {"context": retriever | format_docs, "question": RunnablePassthrough(),"chat_ref": RunnableLambda(lambda x: last_10_chat)}
            | prompt
            | llm
            | StrOutputParser()
    )

    return rag_chain






    # else:
    #     # print(f"Loading existing RAG vector store for '{db_name}'.")
    #     vector_store = Chroma(
    #         persist_directory=persist_directory,
    #         embedding_function=embeddings
    #     )
    #
    # retriever = vector_store.as_retriever(search_kwargs={"k": 3})
    #
    # prompt = ChatPromptTemplate.from_template("""
    # You are an assistant for question-answering tasks. Use the following pieces of retrieved context to answer the question.
    # If you don't know the answer, just say that you don't know.
    #
    # Question: {question}
    # Context: {context}
    # Answer:
    # """)
    #
    # def format_docs(docs):
    #     return "\n\n".join(doc.page_content for doc in docs)
    #
    # rag_chain = (
    #         {"context": retriever | format_docs, "question": RunnablePassthrough()}
    #         | prompt
    #         | llm
    #         | StrOutputParser()
    # )
    #
    # # return rag_chain