import os
import csv
import json
import sqlite3
import shutil
from typing import List, Dict, Any, Optional
from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import google.generativeai as genai
from pypdf import PdfReader
from ai_5_back import run_document_agent
from pathlib import Path
import os
import json
from rag_for_a5 import project_file_rag, chat_with_rag
from simulation_agent import simulation_generator

import re
import json
import os
import ast
from typing import TypedDict, Sequence, Annotated
from pydantic import BaseModel, Field
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, ToolMessage, SystemMessage
from langchain_core.tools import tool
from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings
from langchain_community.document_loaders import PyPDFLoader
# from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough, RunnableLambda
from langchain_core.output_parsers import StrOutputParser
from langgraph.graph import StateGraph, END, START
from langgraph.prebuilt import ToolNode
from graphviz import Digraph
import uuid
import pandas as pd

# app = FastAPI()
#
# # Enable CORS
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

# API_KEY = 'AIzaSyCdz6n34Hj3F-MMGbBrGdsBY1HkMDEXcyQ'
API_KEY = "AIzaSyBDQUbwwapACKQp1Kvx-ydW71m3TespwE4"
PDF_PATH = 'The ethylbenzene production.pdf'
gemini_model = "gemini-2.5-flash-lite"

# Initialize Google Generative AI components
embeddings = GoogleGenerativeAIEmbeddings(
    model="models/text-embedding-004",
    google_api_key=API_KEY
)

llm = ChatGoogleGenerativeAI(
    model=gemini_model,
    google_api_key=API_KEY,
    temperature=0.7,
    max_tokens=None,
    timeout=None,
    max_retries=2,
)

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def clean_string(input_string):
    """
    Removes '```json', '\n', and '```' from a string.
    """
    cleaned_string = input_string.replace('```json', '')
    cleaned_string = cleaned_string.replace('\n', '')
    cleaned_string = cleaned_string.replace('```', '')
    return json.loads(cleaned_string)


# from fastapi import FastAPI
# from pydantic import BaseModel
# from typing import Dict, List, Any

# app = FastAPI()

class ConnectionItem(BaseModel):
    equipment: str
    outlet: List[str] | str | None = None
    Param: Dict[str, Any] | None = None


class FlowsheetInput(BaseModel):
    Equipment_list: Dict[str, str]
    Connection: List[ConnectionItem]


class FlowsheetNode(BaseModel):
    id: str
    type: str
    name: str
    x: float
    y: float
    properties: Dict[str, Any]


class FlowsheetEdge(BaseModel):
    id: str
    from_: str
    to: str


@app.post("/generate_flowsheet")
def generate_flowsheet(payload: FlowsheetInput):
    # print('payload = ',payload)
    equipment_list = payload.Equipment_list
    # print('equipment_list = ',equipment_list)
    connections = payload.Connection
    # equipment_list={"Tank_1": "Tank", "Tanks_2": "Tank", "Heater_1": "Heater"}
    # connections= [{"equipment": "Tank_1", "outlet": ["Heater_1"], "Param": {"Temperature": 300, "Pressure": 1}},
    #                 {"equipment": "Heater_1", "outlet": ["Tanks_2"], "Param": {"Outlet Temperature": 350}}]

    # print('connections = ',connections)

    nodes: Dict[str, FlowsheetNode] = {}
    edges: List[FlowsheetEdge] = []

    # create nodes
    for name, type_str in equipment_list.items():
        conn_data = next((c for c in connections if c.equipment == name), None)
        params = conn_data.Param if conn_data and conn_data.Param else {}
        nodes[name] = FlowsheetNode(
            id=name,
            type=type_str,
            name=name,
            x=0.0,
            y=0.0,
            properties=params,
        )

    # create edges
    for conn in connections:
        from_id = conn.equipment
        outlets = conn.outlet or []
        if isinstance(outlets, str):
            outlets = [outlets]
        for to_id in outlets:
            if from_id in nodes and to_id in nodes:
                edges.append(
                    FlowsheetEdge(
                        id=f"edge-{from_id}-{to_id}",
                        from_=from_id,
                        to=to_id,
                    )
                )

    # simple backend layout (optional, you can reuse BFS idea)
    # here just line them up by index
    for idx, node in enumerate(nodes.values()):
        node.x = 50 + idx * 200
        node.y = 100

    # return {
    #     "nodes": [n.dict() for n in nodes.values()],
    #     "edges": [e.dict() for e in edges],
    # }
    # print('node',{
    #     "nodes": [n.model_dump() for n in nodes.values()],
    #     "edges": [e.model_dump() for e in edges],
    # })
    return {
        "nodes": [n.model_dump() for n in nodes.values()],
        "edges": [e.model_dump() for e in edges],
    }


@app.get("/chemicals", response_model=List[str])
async def get_chemicals():
    chemicals = []
    if os.path.exists(COMPOUNDS_FILE):
        try:
            with open(COMPOUNDS_FILE, mode='r', newline='', encoding='utf-8') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    if 'Name' in row:
                        chemicals.append(row['Name'])
        except Exception as e:
            print(f"Error reading CSV: {e}")
            # Always return a valid list
            return ["Error reading CSV"]
    else:
        return ["Water", "Ethanol", "Methanol"]  # Remove "(Fallback)" for consistency
    return chemicals


# Database Setup
DB_FILE = "projects.db"
UPLOAD_DIR = "uploads"
COMPOUNDS_FILE = "compounds.csv"

# Configure Gemini
# Ensure you set the API_KEY environment variable when running the server
# e.g., export API_KEY="your_key" && python backend/main.py
# API_KEY = os.environ.get("API_KEY")
# API_KEY = 'AIzaSyDsRutviDquMkxuPu2Eq8r2F-HktuGraaQ'
if API_KEY:
    genai.configure(api_key=API_KEY)

if not os.path.exists(UPLOAD_DIR):
    os.makedirs(UPLOAD_DIR)


def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS projects
                 (id TEXT PRIMARY KEY, name TEXT, data TEXT)''')
    c.execute('''CREATE TABLE IF NOT EXISTS files
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, project_id TEXT, filename TEXT, filepath TEXT)''')
    conn.commit()
    conn.close()


init_db()


# Models
class ProjectModel(BaseModel):
    id: str
    name: str
    messages: List[Dict[str, Any]] = []
    nodes: List[Dict[str, Any]] = []
    edges: List[Dict[str, Any]] = []
    results: List[Dict[str, Any]] = []
    files: List[Dict[str, Any]] = []


class ChatRequest(BaseModel):
    message: str


# --- Helper Functions ---

def get_db_connection():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn


# def extract_text_from_file(filepath: str, filename: str) -> str:
#     try:
#         ext = os.path.splitext(filename)[1].lower()
#         if ext == '.pdf':
#             reader = PdfReader(filepath)
#             text = ""
#             for page in reader.pages:
#                 text += page.extract_text() + "\n"
#             return text
#         elif ext in ['.txt', '.csv', '.json', '.md']:
#             with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
#                 return f.read()
#         else:
#             return f"[Unsupported file format: {ext}]"
#     except Exception as e:
#         return f"[Error reading file {filename}: {str(e)}]"


def extract_text_from_file(filepath: str, filename: str) -> str:
    try:
        ext = os.path.splitext(filename)[1].lower()
        if ext == ".pdf":
            reader = PdfReader(filepath)
            parts = [page.extract_text() or "" for page in reader.pages]
            return "\n".join(parts)
        elif ext in [".txt", ".csv"]:  # Add support for other types
            with open(filepath, "r", encoding="utf-8") as f:
                return f.read()
        return "[Unsupported format]"
    except Exception as e:
        return f"[Error reading file {filename}: {str(e)}]"


# def extract_text_from_file(filepath: str, filename: str) -> str:
#     try:
#         ext = os.path.splitext(filename)[1].lower()
#         if ext == ".pdf":
#             reader = PdfReader(filepath)
#             parts = []
#             for page in reader.pages:
#                 parts.append(page.extract_text() or "")
#             return "\n".join(parts)
#         ...
#     except Exception as e:
#         return f"[Error reading file {filename}: {str(e)}]"


# --- Endpoints ---

@app.get("/chemicals", response_model=List[str])
async def get_chemicals():
    """Reads chemicals from the CSV file."""
    chemicals = []
    if os.path.exists(COMPOUNDS_FILE):
        try:
            with open(COMPOUNDS_FILE, mode='r', newline='', encoding='utf-8') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    if 'Name' in row:
                        chemicals.append(row['Name'])
        except Exception as e:
            print(f"Error reading CSV: {e}")
            return ["Error reading CSV"]
    else:
        return ["Water", "Ethanol", "Methanol (Fallback)"]

    return chemicals


@app.get("/projects", response_model=List[ProjectModel])
async def get_projects():
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM projects")
    rows = c.fetchall()
    projects = []
    for row in rows:
        try:
            data = json.loads(row['data'])
            data['id'] = row['id']
            data['name'] = row['name']

            c.execute("SELECT filename FROM files WHERE project_id = ?", (row['id'],))
            files = [{'name': f['filename']} for f in c.fetchall()]
            data['files'] = files

            projects.append(data)
        except json.JSONDecodeError:
            continue
    conn.close()
    return projects


@app.get("/projects/{project_id}", response_model=ProjectModel)
async def get_project(project_id: str):
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM projects WHERE id = ?", (project_id,))
    row = c.fetchone()

    if not row:
        conn.close()
        raise HTTPException(status_code=404, detail="Project not found")

    data = json.loads(row['data'])

    c.execute("SELECT filename FROM files WHERE project_id = ?", (project_id,))
    files = [{'name': f['filename']} for f in c.fetchall()]
    data['files'] = files

    conn.close()
    return data


@app.put("/projects/{project_id}")
async def save_project(project_id: str, project: ProjectModel):
    conn = get_db_connection()
    c = conn.cursor()

    c.execute("SELECT id FROM projects WHERE id = ?", (project_id,))
    exists = c.fetchone()

    project_json = project.json()

    if exists:
        c.execute("UPDATE projects SET name = ?, data = ? WHERE id = ?",
                  (project.name, project_json, project_id))
    else:
        c.execute("INSERT INTO projects (id, name, data) VALUES (?, ?, ?)",
                  (project_id, project.name, project_json))

    conn.commit()
    conn.close()
    return {"message": "Project saved successfully"}


@app.delete("/projects/{project_id}")
async def delete_project(project_id: str):
    conn = get_db_connection()
    c = conn.cursor()

    c.execute("DELETE FROM projects WHERE id = ?", (project_id,))
    c.execute("DELETE FROM files WHERE project_id = ?", (project_id,))
    conn.commit()
    conn.close()

    project_upload_dir = os.path.join(UPLOAD_DIR, project_id)
    if os.path.exists(project_upload_dir):
        shutil.rmtree(project_upload_dir)

    return {"message": "Project deleted successfully"}


# @app.post("/projects/{project_id}/upload")
# async def upload_file(project_id: str, file: UploadFile = File(...)):
#     project_dir = os.path.join(UPLOAD_DIR, project_id)
#     if not os.path.exists(project_dir):
#         os.makedirs(project_dir)
#
#     file_path = os.path.join(project_dir, file.filename)
#     print('upload = ',file_path)
#
#     with open(file_path, "wb") as buffer:
#         shutil.copyfileobj(file.file, buffer)
#
#     conn = get_db_connection()
#     c = conn.cursor()
#     c.execute("INSERT INTO files (project_id, filename, filepath) VALUES (?, ?, ?)",
#               (project_id, file.filename, file_path))
#     conn.commit()
#     conn.close()
#
#     return {"filename": file.filename, "message": "File uploaded successfully"}

@app.post("/projects/{project_id}/upload")
async def upload_file(project_id: str, file: UploadFile = File(...)):
    print('''


    Test case upload''')

    if not project_id.isalnum():
        raise HTTPException(status_code=400, detail="Invalid project ID")

    if not file.filename:
        raise HTTPException(status_code=400, detail="Missing filename")

    if file.content_type != "application/pdf":
        raise HTTPException(
            status_code=400,
            detail=f"Invalid file type: {file.content_type}. Only PDF allowed."
        )

    allowed_extensions = {".pdf", ".csv", ".txt"}
    file_ext = os.path.splitext(file.filename)[1].lower()

    if file_ext not in allowed_extensions:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid file type. Allowed: {allowed_extensions}"
        )
    print('''


    t2''')

    print('file.filename', file.filename)
    print('project_id', project_id)
    file_location = './uploads'

    # if os.path.exists(current_file):
    #     print(f"File '{current_file}' found. Loading data...")
    #     with open(current_file, 'r', encoding='utf-8') as file:
    #         data = json.load(file)
    #
    # else:
    #     print(f"File '{current_file}' not found. Creating it...")
    #     data = {}
    #     with open(current_file, 'w', encoding='utf-8') as file:
    #         json.dump(data, file, indent=4)

    safe_name = os.path.basename(file.filename)

    project_dir = Path(UPLOAD_DIR) / project_id
    project_dir.mkdir(parents=True, exist_ok=True)

    file_path = project_dir / safe_name

    try:
        file.file.seek(0)
        with file_path.open("wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
    finally:
        await file.close()

    project_file_rag(project_id, file.filename)

    conn = get_db_connection()
    c = conn.cursor()
    c.execute(
        "INSERT INTO files (project_id, filename, filepath) VALUES (?, ?, ?)",
        (project_id, safe_name, str(file_path)),
    )
    conn.commit()
    conn.close()

    return {
        "name": safe_name,
        "filename": safe_name,
        "message": "File uploaded successfully",
    }


# @app.post("/projects/{project_id}/upload")
# async def upload_file(project_id: str, file: UploadFile = File(...)):
#     print('project id',project_id)
#     print('upload',file)
#     if not file.filename:
#         raise HTTPException(status_code=400, detail="Missing filename")
#
#     safe_name = os.path.basename(file.filename)
#     # if not safe_name.lower().endswith(".pdf"):
#     #     raise HTTPException(status_code=400, detail="Only PDF files are supported")
#
#     # Line ~330
#     allowed_types = ["application/pdf"]
#
#     if file.content_type not in allowed_types:
#         raise HTTPException(
#             status_code=400,
#             detail=f"Invalid file type: {file.content_type}. Only PDF allowed."
#         )
#
#     project_dir = Path(UPLOAD_DIR) / project_id
#     project_dir.mkdir(parents=True, exist_ok=True)
#
#     file_path = project_dir / safe_name
#
#     try:
#         # with file_path.open("wb") as buffer:
#         #     shutil.copyfileobj(file.file, buffer)
#
#         file.file.seek(0)  # <-- CRITICAL
#
#         with file_path.open("wb") as buffer:
#             shutil.copyfileobj(file.file, buffer)
#
#     finally:
#         await file.close()
#
#     conn = get_db_connection()
#     c = conn.cursor()
#     c.execute(
#         "INSERT INTO files (project_id, filename, filepath) VALUES (?, ?, ?)",
#         (project_id, safe_name, str(file_path)),
#     )
#     conn.commit()
#     conn.close()
#
#     return {
#         "name": safe_name,       # <-- frontend-friendly
#         "filename": safe_name,   # <-- keep old key too
#         "message": "File uploaded successfully",
#     }


@app.post("/projects/{project_id}/chat")
async def chat_with_project(project_id: str, request: ChatRequest):
    # "chat_history db and reference "
    # chat_history_json = Path(f'./chat_bin/{project_id}.json')
    # chat_history_json.parent.mkdir(parents=True, exist_ok=True)
    # if chat_history_json.exists():
    #     print(f"File '{chat_history_json}' found. Loading data...")
    #     with open(chat_history_json, 'r', encoding='utf-8') as f:
    #         data = json.load(f)
    # else:
    #     print(f"File '{chat_history_json}' not found. Creating it...")
    #     data = {'Chat_History': []}
    #     print('''
    #
    #     data = from chat''', data)
    #
    # last_10_chat= (data['Chat_History'])[-20:]
    #
    # print('last_10_chat=',last_10_chat)
    #
    #
    # # project_dir = os.path.join(UPLOAD_DIR, project_id)
    # # context_text = ""
    # #
    # # if os.path.exists(project_dir):
    # #     files = os.listdir(project_dir)
    # #     for filename in files:
    # #         file_path = os.path.join(project_dir, filename)
    # #         content = extract_text_from_file(file_path, filename)
    # #         context_text += f"\n--- File: {filename} ---\n{content}\n"
    #
    #
    #
    # "Process deciding AI  RAG or simualtion"
    #
    # select_rag_or_sim=clean_string((llm.invoke([SystemMessage(content='''You are a deciding agent which suggest which task we need to perform based on the message user provide
    # make sure you return response only in the json format in the followin way
    # you can perform two task answer question and simulation
    # the simulation task is performed only if the user specify the agent to simulate for all other message send to answer question
    # the response should always be in JSON structure ,follow the same structure
    # {'Task':'Simulate'} or {'Task':'Answer Question'}
    #
    # '''),HumanMessage(content=request.message)])).content)
    #
    # print('select_rag_or_sim=',select_rag_or_sim)
    #
    # if select_rag_or_sim['Task'] == 'Simulate':
    #     sim_agent=simulation_generator(project_id,last_10_chat)
    #     ai_respo=clean_string(sim_agent.invoke(request.message))
    #     print('sim respond',ai_respo)
    #     if "Data" in list(ai_respo.keys()):
    #         ai_respo="Data is insuffecient please provide more data"
    #     else:
    #         ai_respo=json.dumps(ai_respo)
    #
    # else:
    #     BASE_DIR = Path(__file__).resolve().parent
    #     persist_directory = (BASE_DIR / "rag_db" / str(project_id))
    #     if chat_history_json.exists():
    #         print('checking rag')
    #         ai_to_talk=chat_with_rag(project_id,last_10_chat)
    #         print('reply from rag',ai_to_talk)
    #
    #     else:
    #         print('normal reply enter')
    #         prompt = ChatPromptTemplate.from_template("""
    #             Consider you are a chemical engineering assistant . you need to answer the question in the following format.
    #     If the question is not related to chemical , chemical engineering or bio response only by saying "Sorry, i can respond only for chemical engineering questions"
    #     the chat reference show the last 10 chat between human question and ai respond
    #             Question: {question}
    #             chat_ref:{chat_ref}
    #             Answer:
    #             """)
    #
    #         def format_docs(docs):
    #             return "\n\n".join(doc for doc in docs)
    #
    #
    #
    #         ai_to_talk = (
    #                 {"question": RunnablePassthrough(),"chat_ref": RunnableLambda(lambda x: last_10_chat)  }
    #                 | prompt
    #                 | llm
    #                 | StrOutputParser()
    #         )
    #         print('ai_to_talk',ai_to_talk)
    #
    #     ai_respo=ai_to_talk.invoke(request.message)
    #     print('ai_respo',ai_respo)
    #
    #
    #
    #
    # data['Chat_History']=data['Chat_History']+[str(request.message),str(ai_respo)]
    #
    #
    #
    # with open(chat_history_json, 'w', encoding='utf-8') as f:
    #     json.dump(data, f, indent=4)

    ai_respo = {'Equipment_list': {'Feed_1': 'Feed', 'Heater_1': 'Heater', 'Pump_1': 'Pump', 'Reactor_1': 'Reactor',
                                   'Cooler_1': 'Cooler', 'DistillationColumn_1': 'DistillationColumn',
                                   'Product_1': 'Product', 'Product_2': 'Product'}, 'Connection': [
        {'equipment': 'Feed_1', 'outlet': ['Heater_1'],
         'Param': {'temperature': 368.15, 'pressure': 1.01325, 'flowRate': 9.419034,
                   'compounds': [{'name': 'Benzene', 'moleFraction': 0.5}, {'name': 'Ethylene', 'moleFraction': 0.5}]}},
        {'equipment': 'Heater_1', 'outlet': ['Pump_1'], 'Param': {'outletTemperature': 368.15}},
        {'equipment': 'Pump_1', 'outlet': ['Reactor_1'], 'Param': {'outletPressure': 13}},
        {'equipment': 'Reactor_1', 'outlet': ['Cooler_1'], 'Param': {'conversion': 0.7}},
        {'equipment': 'Cooler_1', 'outlet': ['DistillationColumn_1'], 'Param': {'outletTemperature': 423.15}},
        {'equipment': 'DistillationColumn_1', 'outlet': ['Product_2', 'Product_1'],
         'Param': {'Stages': 20, 'condenserType': 'Total', 'refluxRatio': 1.5, 'pressure': 1.01325,
                   'splitRatios': {'Product_2': 0.5, 'Product_1': 0.5}}},
        {'equipment': 'Product_1', 'outlet': [], 'Param': {}}, {'equipment': 'Product_2', 'outlet': [], 'Param': {}}]}

    return {'text': json.dumps(ai_respo)}

    # try:
    # # model = genai.GenerativeModel('gemini-2.5-flash')
    # # response = model.generate_content(prompt)
    # # message= run_document_agent(prompt)
    #     print('MessaGE:',request.message)
    #     try:
    #
    #         # equipment_list = payload.Equipment_list
    #         # connections = payload.Connection
    #         # equipment_list = {"Tank_1": "Tank", "Tanks_2": "Tank", "Heater_1": "Heater"}
    #         # connections = [
    #         #     {"equipment": "Tank_1", "outlet": ["Heater_1"], "Param": {"Temperature": 300, "Pressure": 1}},
    #         #     {"equipment": "Heater_1", "outlet": ["Tanks_2"], "Param": {"Outlet Temperature": 350}}]
    #         # equipment_list = {"Tank_1": "Tank", "Tanks_2": "Tank", "Heater_1": "Heater"}
    #         # connections = [
    #         #     {"equipment": "Tank_1", "outlet": ["Heater_1"], "Param": {"Temperature": 300, "Pressure": 1}},
    #         #     {"equipment": "Heater_1", "outlet": ["Tanks_2"], "Param": {"Outlet Temperature": 350}}]
    #         #
    #         # # POST to http://localhost:8000/generate_flowsheet
    #         # payload = {"Equipment_list": equipment_list, "Connection": connections}
    #         payload={'Equipment_list': {'Feed_1': 'Feed',
    #     'Pump_1': 'Pump',
    #     'Reactor_1': 'Reactor',
    #     'Cooler_1': 'Cooler',
    #     'DistillationColumn_1': 'DistillationColumn',
    #     'Product_1': 'Product',
    #     'Product_2': 'Product'},
    #     'Connection': [{'equipment': 'Feed_1',
    #     'outlet': ['Pump_1'],
    #     'Param': {'Temperature': 368.15,
    #     'Pressure': 1.01325,
    #     'Flow Rate': 9.419034,
    #     'Compounds': [{'name': 'Benzene', 'moleFraction': 0.5},
    #     {'name': 'Ethylene', 'moleFraction': 0.5}]}},
    #     {'equipment': 'Pump_1',
    #     'outlet': ['Reactor_1'],
    #     'Param': {'Outlet Pressure': 13}},
    #     {'equipment': 'Reactor_1',
    #     'outlet': ['Cooler_1'],
    #     'Param': {'Temperature': None,
    #     'Pressure': None,
    #     'Conversion': {'Benzene': 0.7}}},
    #     {'equipment': 'Cooler_1',
    #     'outlet': ['DistillationColumn_1'],
    #     'Param': {'Outlet Temperature': 423.15}},
    #     {'equipment': 'DistillationColumn_1',
    #     'outlet': ['Product_1', 'Product_2'],
    #     'Param': {'Stages': 20,
    #     'Condenser Type': 'Total',
    #     'Reflux Ratio': 1.5,
    #     'Pressure': None}},
    #     {'equipment': 'Product_1', 'outlet': [], 'Param': {}},
    #     {'equipment': 'Product_2', 'outlet': [], 'Param': {}}]}
    #         fs_input = FlowsheetInput(**payload)
    #         generate_flowsheet(fs_input)
    #         # return  {'text':json.dumps(payload)}#str(payload)
    #     except:
    #         print('graph error')
    #     return {'text':'working'}#message}#{"text": response.text}
    # except Exception as e:
    #     print(f"GenAI Error: {e}")
    #     return {"text": f"Error communicating with AI: {str(e)}"}


# --- Line 300+: Add Simulation Logic ---

class SimulationRequest(BaseModel):
    nodes: List[Dict[str, Any]]
    edges: List[Dict[str, Any]]


@app.post("/projects/{project_id}/simulate")
async def simulate_project(project_id: str, request: SimulationRequest):
    print('simulation_rpoject enter ')
    nodes = request.nodes
    print('request', request)
    results_map = {}  # { Attribute: { Equipment: Value } }

    # Initialize attributes as per Datatable.csv
    attributes = ["Equipment", "Temperature (C)", "Pressure (bar)", "Molar Flowrate (mol/s)", "Energy"]
    for attr in attributes:
        results_map[attr] = {"Attribute": attr}

    for node in nodes:
        name = node.get('name', 'Unknown')
        props = node.get('properties', {})
        n_type = node.get('type')

        # Map properties to table rows
        results_map["Equipment"][name] = name
        results_map["Temperature (C)"][name] = props.get('temperature') or props.get('outletTemperature', 'N/A')
        results_map["Pressure (bar)"][name] = props.get('pressure') or props.get('outletPressure', 'N/A')
        results_map["Molar Flowrate (mol/s)"][name] = props.get('flowRate', 'N/A')
        results_map["Energy"][name] = props.get('energy', '')

        # Handle Compounds (Mole Fractions)
        compounds = props.get('compounds', [])
        for comp in compounds:
            comp_name = comp.get('name')
            if comp_name not in results_map:
                results_map[comp_name] = {"Attribute": comp_name}
            results_map[comp_name][name] = comp.get('moleFraction', 0)

    # Convert map back to list of objects for the frontend
    final_data = list(results_map.values())

    # Save results to DB
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT data FROM projects WHERE id = ?", (project_id,))
    row = c.fetchone()
    if row:
        project_data = json.loads(row['data'])
        project_data['results'] = final_data
        c.execute("UPDATE projects SET data = ? WHERE id = ?", (json.dumps(project_data), project_id))
        conn.commit()
    conn.close()

    return final_data


@app.post("/projects/{project_id}/run")
async def run_simulation(project_id: str, project_data: ProjectModel):
    print('run_simulation enter ')
    nodes = project_data.nodes
    print('project_data', project_data)
    results = []

    id_counter = 1

    for node in nodes:
        props = node.get('properties', {})
        name = node.get('name', 'Unknown')
        n_type = node.get('type', '')

        if n_type == 'Reactor':
            temp = props.get('temperature', 350)
            results.append({
                "id": id_counter,
                "Equipment": name,
                "Parameter": "Temperature",
                "Value": f"{temp} K",
                "Status": "Nominal"
            })
            id_counter += 1
            results.append({
                "id": id_counter,
                "Equipment": name,
                "Parameter": "Conversion",
                "Value": "92.5%",
                "Status": "Excellent"
            })
            id_counter += 1

        elif n_type == 'DistillationColumn':
            results.append({
                "id": id_counter,
                "Equipment": name,
                "Parameter": "Purity",
                "Value": "99.8%",
                "Status": "Nominal"
            })
            id_counter += 1
            results.append({
                "id": id_counter,
                "Equipment": name,
                "Parameter": "Heat Duty",
                "Value": "2.5 MW",
                "Status": "High"
            })
            id_counter += 1

        elif n_type == 'Feed':
            flow = props.get('flowRate', 0)
            compounds = props.get('compounds', [])
            comp_str = ", ".join([f"{c['name']} ({c['moleFraction']})" for c in compounds]) if compounds else "None"

            results.append({
                "id": id_counter,
                "Equipment": name,
                "Parameter": "Flow Rate",
                "Value": f"{flow} kmol/hr",
                "Status": "Nominal"
            })
            id_counter += 1
            results.append({
                "id": id_counter,
                "Equipment": name,
                "Parameter": "Composition",
                "Value": comp_str,
                "Status": "Info"
            })
            id_counter += 1

        else:
            results.append({
                "id": id_counter,
                "Equipment": name,
                "Parameter": "Status",
                "Value": "Active",
                "Status": "Nominal"
            })
            id_counter += 1

    if not results:
        results = [{"id": 0, "Info": "No equipment to simulate."}]

    return results


@app.post("/projects/{project_id}/simulate")
async def run_simulation(project_id: str, payload: Dict[Any, Any]):
    print('run_simulation enter 2')
    nodes = payload.get("nodes", [])
    print('payload', payload)

    # 1. Define the rows we want to see (Matching Datatable.csv)
    attributes = [
        "Equipment",
        "Temperature (C)",
        "Pressure (bar)",
        "Molar Flowrate (mol/s)",
        "Benzene",
        "Ethylene"
    ]

    # 2. Create a map for each row
    pivoted_data = {attr: {"Attribute": attr} for attr in attributes}

    # 3. Fill the map by iterating through nodes
    for node in nodes:
        name = node.get("name", "Unknown")
        props = node.get("properties", {})

        pivoted_data["Equipment"][name] = name
        pivoted_data["Temperature (C)"][name] = props.get("temperature", "N/A")
        pivoted_data["Pressure (bar)"][name] = props.get("pressure", "N/A")
        pivoted_data["Molar Flowrate (mol/s)"][name] = props.get("flowRate", "N/A")

        # Handle Compounds
        compounds = props.get("compounds", [])
        for c in compounds:
            c_name = c.get("name")
            if c_name in pivoted_data:
                pivoted_data[c_name][name] = c.get("moleFraction", 0)

    # 4. Convert back to list of objects for frontend ResultTable.tsx
    final_response = list(pivoted_data.values())

    return JSONResponse(content=final_response)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)