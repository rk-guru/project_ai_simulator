
export interface Step {
  id: string;
  command: string;
}

export interface ProjectSettings {
  model: string;
  apiKey: string;
}

export interface Project {
  id: string;
  name: string;
  targetUrl: string;
  steps: Step[];
  settings: ProjectSettings;
}