
import { Project } from './types';

export const AI_MODELS: string[] = [
  'gemini-2.5-flash',
  'gemini-2.5-pro',
  'LLAMA',
  'ChatGPT',
  'Qwen',
  'DeepSeek',
  'Claude',
];

export const INITIAL_PROJECTS: Project[] = [
  {
    id: 'proj1',
    name: 'Login Test',
    targetUrl: 'https://example.com/login',
    steps: [
      { id: 'step1', command: 'TYPE #username testuser' },
      { id: 'step2', command: 'TYPE #password password123' },
      { id: 'step3', command: 'CLICK button[type="submit"]' },
    ],
    settings: {
      model: 'gemini-2.5-flash',
      apiKey: '',
    },
  },
  {
    id: 'proj2',
    name: 'Search for Kittens',
    targetUrl: 'https://google.com',
    steps: [
      { id: 'step4', command: 'TYPE input[name="q"] cute kittens' },
      { id: 'step5', command: 'CLICK input[name="btnK"]' },
    ],
    settings: {
      model: 'gemini-2.5-pro',
      apiKey: '',
    },
  },
];