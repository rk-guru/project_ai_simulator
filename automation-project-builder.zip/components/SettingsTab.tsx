
import React from 'react';
import { ProjectSettings } from '../types';
import { AI_MODELS } from '../constants';

interface SettingsTabProps {
  settings: ProjectSettings;
  onSettingsChange: (settings: ProjectSettings) => void;
}

const SettingsTab: React.FC<SettingsTabProps> = ({ settings, onSettingsChange }) => {
  return (
    <div className="max-w-md space-y-6">
      <div>
        <label htmlFor="aiModel" className="block text-sm font-medium text-slate-400">
          AI Model
        </label>
        <select
          id="aiModel"
          value={settings.model}
          onChange={(e) => onSettingsChange({ ...settings, model: e.target.value })}
          className="mt-1 block w-full bg-slate-900 border-slate-700 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm p-2.5"
        >
          {AI_MODELS.map(model => (
            <option key={model} value={model}>
              {model}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label htmlFor="apiKey" className="block text-sm font-medium text-slate-400">
          API Key
        </label>
        <input
          type="password"
          id="apiKey"
          value={settings.apiKey || ''}
          onChange={(e) => onSettingsChange({ ...settings, apiKey: e.target.value })}
          placeholder="Enter your API key"
          className="mt-1 block w-full bg-slate-900 border-slate-700 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm p-2.5"
        />
      </div>
    </div>
  );
};

export default SettingsTab;