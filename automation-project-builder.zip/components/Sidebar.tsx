
import React from 'react';
import { Project } from '../types';
import { PlusIcon } from './icons/PlusIcon';

interface SidebarProps {
  projects: Project[];
  selectedProjectId: string | null;
  onCreateProject: () => void;
  onSelectProject: (id: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({
  projects,
  selectedProjectId,
  onCreateProject,
  onSelectProject,
}) => {
  return (
    <aside className="w-64 bg-slate-950 p-4 border-r border-slate-800 flex flex-col">
      <button
        onClick={onCreateProject}
        className="flex items-center justify-center w-full px-4 py-2 mb-6 text-sm font-semibold text-white bg-indigo-600 rounded-md hover:bg-indigo-700 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-indigo-500"
      >
        <PlusIcon className="w-5 h-5 mr-2" />
        Create New Project
      </button>

      <h2 className="text-xs font-bold tracking-wider text-slate-500 uppercase">
        Saved Projects
      </h2>
      <nav className="mt-4 flex-1">
        <ul>
          {projects.map(project => (
            <li key={project.id}>
              <button
                onClick={() => onSelectProject(project.id)}
                className={`w-full text-left px-3 py-2 text-sm rounded-md transition-colors ${
                  selectedProjectId === project.id
                    ? 'bg-indigo-600 text-white font-semibold'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                {project.name}
              </button>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;
