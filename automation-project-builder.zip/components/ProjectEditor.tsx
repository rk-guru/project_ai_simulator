
import React, { useState, useCallback } from 'react';
import { Project, Step } from '../types';
import StepList from './StepList';
import SettingsTab from './SettingsTab';
import { SaveIcon } from './icons/SaveIcon';
import { PlayIcon } from './icons/PlayIcon';

interface ProjectEditorProps {
  project: Project;
  onUpdateProject: (project: Project) => void;
}

type Tab = 'steps' | 'settings';

const ProjectEditor: React.FC<ProjectEditorProps> = ({ project, onUpdateProject }) => {
  const [activeTab, setActiveTab] = useState<Tab>('steps');
  const [name, setName] = useState(project.name);
  const [targetUrl, setTargetUrl] = useState(project.targetUrl);
  const [result, setResult] = useState('Run results will appear here...');
  const [isRunning, setIsRunning] = useState(false);

  const handleUpdate = useCallback(<K extends keyof Project>(key: K, value: Project[K]) => {
    onUpdateProject({ ...project, [key]: value });
  }, [project, onUpdateProject]);

  const handleRun = () => {
    setIsRunning(true);
    setResult('Running project...');
    setTimeout(() => {
      setResult(`Project "${project.name}" ran successfully.\n\nTarget: ${project.targetUrl}\nSteps executed: ${project.steps.length}`);
      setIsRunning(false);
    }, 2000);
  };

  const handleSave = () => {
    // In a real app, this would trigger a save to a backend.
    // Here we just update the local state which is already happening on change.
    // We can add a visual indicator for saving.
    console.log('Project saved:', project);
  };

  const handleStepsChange = (newSteps: Step[]) => {
    handleUpdate('steps', newSteps);
  };
  
  const handleSettingsChange = (newSettings: Project['settings']) => {
    handleUpdate('settings', newSettings);
  };

  return (
    <div className="space-y-6 h-full flex flex-col">
      <div className="space-y-4">
        <div>
          <label htmlFor="projectName" className="block text-sm font-medium text-slate-400">Project Name</label>
          <input
            type="text"
            id="projectName"
            value={name}
            onChange={(e) => {
              setName(e.target.value);
              handleUpdate('name', e.target.value);
            }}
            className="mt-1 block w-full bg-slate-800 border-slate-700 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm p-2"
          />
        </div>
        <div>
          <label htmlFor="targetUrl" className="block text-sm font-medium text-slate-400">Target URL</label>
          <input
            type="text"
            id="targetUrl"
            value={targetUrl}
            onChange={(e) => {
              setTargetUrl(e.target.value);
              handleUpdate('targetUrl', e.target.value);
            }}
            className="mt-1 block w-full bg-slate-800 border-slate-700 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm p-2"
          />
        </div>
      </div>

      <div className="flex-grow flex flex-col bg-slate-800/50 rounded-lg p-6">
        <div className="border-b border-slate-700">
          <nav className="-mb-px flex space-x-6" aria-label="Tabs">
            <button
              onClick={() => setActiveTab('steps')}
              className={`${
                activeTab === 'steps' ? 'border-indigo-500 text-indigo-400' : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-500'
              } whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-colors`}
            >
              Steps
            </button>
            <button
              onClick={() => setActiveTab('settings')}
              className={`${
                activeTab === 'settings' ? 'border-indigo-500 text-indigo-400' : 'border-transparent text-slate-400 hover:text-slate-200 hover:border-slate-500'
              } whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-colors`}
            >
              Settings
            </button>
          </nav>
        </div>
        <div className="pt-6 flex-grow">
          {activeTab === 'steps' ? (
            <StepList steps={project.steps} onStepsChange={handleStepsChange} />
          ) : (
            <SettingsTab settings={project.settings} onSettingsChange={handleSettingsChange} />
          )}
        </div>
      </div>

      <div>
        <label htmlFor="result" className="block text-sm font-medium text-slate-400">Result</label>
        <textarea
          id="result"
          readOnly
          value={result}
          rows={5}
          className="mt-1 block w-full bg-slate-800 border-slate-700 rounded-md shadow-sm sm:text-sm p-2 font-mono"
        />
      </div>

      <div className="flex justify-end space-x-4 pt-4 border-t border-slate-800">
        <button
            onClick={handleSave}
            className="flex items-center justify-center px-4 py-2 text-sm font-semibold text-slate-200 bg-slate-700 rounded-md hover:bg-slate-600 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-slate-500"
        >
            <SaveIcon className="w-5 h-5 mr-2" />
            Save
        </button>
        <button
            onClick={handleRun}
            disabled={isRunning}
            className="flex items-center justify-center px-6 py-2 text-sm font-semibold text-white bg-green-600 rounded-md hover:bg-green-700 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-green-500 disabled:bg-green-800 disabled:cursor-not-allowed"
        >
            <PlayIcon className="w-5 h-5 mr-2" />
            {isRunning ? 'Running...' : 'Run'}
        </button>
      </div>
    </div>
  );
};

export default ProjectEditor;

