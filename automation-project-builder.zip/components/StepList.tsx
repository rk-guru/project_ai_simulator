
import React, { useCallback } from 'react';
import { Step } from '../types';
import { TrashIcon } from './icons/TrashIcon';
import { PlusIcon } from './icons/PlusIcon';

interface StepListProps {
  steps: Step[];
  onStepsChange: (steps: Step[]) => void;
}

const StepList: React.FC<StepListProps> = ({ steps, onStepsChange }) => {
  const handleAddStep = useCallback(() => {
    const newStep: Step = { id: `step${Date.now()}`, command: '' };
    onStepsChange([...steps, newStep]);
  }, [steps, onStepsChange]);

  const handleUpdateStep = useCallback((id: string, newCommand: string) => {
    const newSteps = steps.map(step =>
      step.id === id ? { ...step, command: newCommand } : step
    );
    onStepsChange(newSteps);
  }, [steps, onStepsChange]);

  const handleDeleteStep = useCallback((id: string) => {
    const newSteps = steps.filter(step => step.id !== id);
    onStepsChange(newSteps);
  }, [steps, onStepsChange]);

  return (
    <div className="space-y-3">
      <div className="px-3 pb-2">
        <p className="text-xs font-semibold text-slate-500 tracking-wider">COMMAND</p>
      </div>
      {steps.map((step, index) => (
        <div key={step.id} className="flex items-center space-x-3">
          <input
            type="text"
            value={step.command}
            onChange={(e) => handleUpdateStep(step.id, e.target.value)}
            placeholder={`Step ${index + 1}`}
            className="flex-grow bg-slate-900 border border-slate-700 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm p-2.5"
          />
          <button
            onClick={() => handleDeleteStep(step.id)}
            className="p-2 text-slate-400 hover:text-red-500 rounded-md transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-red-500"
          >
            <TrashIcon className="w-5 h-5" />
          </button>
        </div>
      ))}
      <div className="pt-3">
        <button
          onClick={handleAddStep}
          className="flex items-center px-3 py-2 text-sm font-medium text-indigo-400 hover:text-indigo-300 transition-colors focus:outline-none"
        >
          <PlusIcon className="w-5 h-5 mr-2" />
          Add Step
        </button>
      </div>
    </div>
  );
};

export default StepList;
