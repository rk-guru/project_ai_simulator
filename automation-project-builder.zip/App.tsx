
import React, { useState, useCallback } from 'react';
import { Project } from './types';
import { INITIAL_PROJECTS } from './constants';
import Sidebar from './components/Sidebar';
import ProjectEditor from './components/ProjectEditor';

const App: React.FC = () => {
  const [projects, setProjects] = useState<Project[]>(INITIAL_PROJECTS);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>('proj1');

  const handleCreateNewProject = useCallback(() => {
    const newId = `proj${Date.now()}`;
    const newProject: Project = {
      id: newId,
      name: 'New Project',
      targetUrl: '',
      steps: [],
      settings: { model: 'gemini-2.5-flash', apiKey: '' },
    };
    setProjects(prev => [...prev, newProject]);
    setSelectedProjectId(newId);
  }, []);

  const handleSelectProject = useCallback((id: string) => {
    setSelectedProjectId(id);
  }, []);

  const handleUpdateProject = useCallback((updatedProject: Project) => {
    setProjects(prev =>
      prev.map(p => (p.id === updatedProject.id ? updatedProject : p))
    );
  }, []);

  const selectedProject = projects.find(p => p.id === selectedProjectId);

  return (
    <div className="flex h-screen bg-slate-900 text-slate-200 font-sans">
      <Sidebar
        projects={projects}
        selectedProjectId={selectedProjectId}
        onCreateProject={handleCreateNewProject}
        onSelectProject={handleSelectProject}
      />
      <main className="flex-1 p-8 overflow-y-auto">
        {selectedProject ? (
          <ProjectEditor
            key={selectedProject.id}
            project={selectedProject}
            onUpdateProject={handleUpdateProject}
          />
        ) : (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <h2 className="text-2xl font-semibold text-slate-400">No Project Selected</h2>
              <p className="mt-2 text-slate-500">Create a new project or select one from the list to get started.</p>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;